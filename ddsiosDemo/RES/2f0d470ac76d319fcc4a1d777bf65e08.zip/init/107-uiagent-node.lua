require('luabin')
luabin.path = playerconf.DUICORE_HOME .. '/hybrid.lub;' .. playerconf.DATA_HOME .. '/core.lub'

local uiagentnode = require 'player.node.uiagent'
uiagentnode:run()
