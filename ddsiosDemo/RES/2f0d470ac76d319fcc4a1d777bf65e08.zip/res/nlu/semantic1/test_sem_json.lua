-- 配置luapath,主要是so和lua引用库的路径
package.cpath = "/home/aisp/Workspace/semantic_v3_lua/libs/semantic.so"
package.path = "./semantic/?.lua;./?.lua"
print (package.path)

-- 引用相关的库
local nlucore = require 'nlucore'
local json = require 'utils.json'


local function print_help()
    print("lua ".. arg[0].."-d res_dir -v vocabs_path -s text [-i infile] -o outfile -env env_params")
end


local function test_str(nlu,text,envparam)
    local inputdata;

    inputdata = json.decode(text);

    if not inputdata or type(inputdata) ~= "table" then
        inputdata = {};
        inputdata.refText = text;
    end

    if not inputdata.env and envparam and  envparam ~= "" then
        inputdata.env = envparam;
    end


    table.print(inputdata)
    local jsinput = json.encode(inputdata)
    print(jsinput)
    local result = nlu:feed_json(jsinput);
    nlu:reset();
    return result;

end




function main()
    local text = nil
    local infile = nil
    local outfile = nil
    local env_param = nil
    local res_path = nil
    local vocab_path = nil

    --命令行参数处理
    local argcount = #arg
    local i = 1
    while i< argcount do 
        if arg[i] == "-s" then 
            text = arg[i+1]
            i=i+1
        elseif arg[i] == "-i" then
            infile = arg[i+1]
            i=i + 1
        elseif arg[i] == "-o" then 
            outfile  = arg[i+1]
            i = i+ 1
        elseif arg[i] == "-env" then 
            env_param  = arg[i+1]
            i = i+ 1
        elseif arg[i] == "-d" then
            res_path = arg[i+1]
            i = i+1
        elseif arg[i] == "-v" then
            vocab_path = arg[i+1]
            i = i+1
        end
        i=i+1
    end
    
    if res_path== nil or res_path == "" then
        print_help()
        return
    end

    if (text==nil or text=="") and (infile ==nil or infile =="") then
        print_help()
        return 
    end


    --为了兼容之前的测试脚本,添加默认路径为  资源目录/lex/vocabs
    if not vocab_path then
        vocab_path = res_path.."/lex/vocabs/"
    end

    --nlucore初始化
    local fn_cfg   = "nlucfg.lua"               --默认都用这个名字
    --res_path   = "/home/hx055/hxdata3/NLP/work2017/works/semantic_rewrite/src/semantic_v3_lua/src/res1/aihome/" 
    --local vocabs_path = {res_path.."/../vocabs/"}  --这个必须要有,lexcfg.lua可以只配置词库名称
    local vocabs_path = {vocab_path}  --这个必须要有,lexcfg.lua可以只配置词库名称


    if text and text ~= "" then
        local nlu = nlucore.new(fn_cfg,res_path,vocabs_path)
        nlu:preload_lex_resources()
        nlu.use_trace = true
        --nlu.debug = true

        local result = test_str(nlu,text,env_param)
        nlu = nil

        print("input: "..text)
        print(result)
    elseif infile and infile ~="" then
        local fr = io.open(infile,"r")
        local fw = nil
        if outfile and outfile ~="" then
            fw = io.open(outfile,"w")
        end
        local nlu = nlucore.new(fn_cfg,res_path,vocabs_path)
        nlu.debug = false
        nlu:preload_lex_resources()

        while true do
            local line = fr:read("*l")
            if not line then
                break
            end

            local resjson = test_str(nlu,line,env_param)

            if fw then
                fw:write("input: "..line.."\n")
                fw:write(resjson .. "\n")     
            else
                print("input: "..line) 
                print(resjson)
            end
            resjson = nil

        end
        fr:close()
        if fw then 
            fw:close()
        end
    end

    nlu = nil
    collectgarbage("collect")
end

main()


