require("utils.base")
local M = {}

local core = require("engine.core")

M.opts = {}
M.pinyin = {
    input = "",
    pwd = "",
    cfg =  {
        bin_fn = "",
        wrd_fn = ""
    }  
}
--************************************************************************--
--                            reform functions                            --
--************************************************************************--
function M:is_use_slot_index()
    local ret = false
    if self.opts then
        if self.opts.use_slot_index then
            ret = self.opts.use_slot_index
        end
    end
    return ret
end    

function M:gsub_wordstring(input,value, start_pos, end_pos )    
    local num, spos, epos, str, pinyin

    if start_pos == -1 and end_pos == -1 then
        return "",""
    end
    
    --str = M.processor.input
    spos = 1;
    epos = 1;
    num = 1
    for i=1, start_pos do
        num = core:word_bytes(string.sub(input,spos))
        spos = num + spos
    end
    
    for i=1, end_pos+1 do
        num = core:word_bytes(string.sub(input,epos))
        epos = num + epos
    end

    str = string.sub(input,spos,epos-1)
    pinyin = self:attach_slot_pinyin(str,start_pos,end_pos)    
    return str,pinyin
end

function M:gsub_wordstring_wtk(input, value, start_pos, end_pos )    
    local num, spos, epos, str, pinyin
    
    --str = M.processor.input
    --[[
    if start_pos == -1 and end_pos == -1 then
        return "",""
    end
    
    spos = 1;
    epos = 1;
    num = 1
    for i=1, start_pos do
        num = core:word_bytes(string.sub(input,spos))
        spos = num + spos
    end
    
    for i=1, end_pos+1 do
        num = core:word_bytes(string.sub(input,epos))
        epos = num + epos
    end
--]]
    --str = string.sub(input,spos,epos-1)
    local str
    local found = false
    local separator = string.match(value,"[%^&!|%s]")    
    if not separator then
        separator = " "
    end    
    
    for s in string.gmatch(value,"([^&!|%s]+)") do              
        --str = self:attach_slot_pinyin(s,1,string.len(s))
        str = self:attach_slot_pinyin(s,start_pos,end_pos)
        if str then
            if not found then
                pinyin = str
            elseif separator == " " then               
                pinyin = pinyin..separator..str                     
            else
                pinyin = pinyin.." "..separator.." "..str
            end
        found = true  
        end        
    end    
    return str,pinyin
end

function M:reform_slot( input, slot )    
    local result = {}
    local key
        
    for k, v in pairs(slot) do
        local tmp = {}        
        if k ~= "__WEIGHT__" and k ~= "__RE_START__" and k~= "__RE_END__" and k ~= "__SLOT_START__" and k ~= "__SLOT_END__" and k~="__KEY__" and k~="__NAME__" and k~="__SEQ__" and k~="__ID__" then
            key = k
            if string.find(k,"+") then
                key = (string.gsub(k,"+","."))                            
            end
            tmp["name"]  = key            
            if type(v) == "table" then  
                local idx = 1
                if table.maxn(v) == 3 then              
                    tmp["value"] = v[1]
                    idx = idx + 1
                else
                    tmp["value"] = ""
                end
                if tmp["value"] == "" then
                    break;
                end    
                if self:is_use_slot_index() then
                    tmp.pos = {}
                    tmp.pos[1] = v[idx]
                    tmp.pos[2] = v[idx+1]
                    if tmp.pos[1] == -1 and tmp.pos[2]==-1 then
                        tmp.pos = nil
                    else
                        tmp["rawvalue"],tmp["rawpinyin"] = self:gsub_wordstring(input,tmp.value,tmp.pos[1],tmp.pos[2])
                    end
                end
            else
                if v == "" then
                    break
                end
                tmp["value"] = v
            end
        table.insert(result,tmp)        
        end
    end                    
    return result
end

function M:reform_tokens( input, tokens )    
    local result = {}
    local slots
    local cnt
    
    cnt = 0    
    for k,v in pairs(tokens) do        
        slots = self:reform_slot(input,v)
        for i=1, table.maxn(slots) do
            cnt = cnt + 1        
            table.insert(result,slots[i])
        end
    end                
    
    return result,cnt
end

local pinyin_soundex_slot={}    

function M:reform_slot_with_old_format( input, slot )    
    local result = {}
    local key
        
    for k, v in pairs(slot) do                
        if k ~= "__WEIGHT__" and k ~= "__RE_START__" and k~= "__RE_END__" and k ~= "__SLOT_START__" and k ~= "__SLOT_END__" and k~="__KEY__" and k~="__NAME__" and k~="__SEQ__" and k~="__ID__" then
            key = k
            if type(k) == "string" then
                if string.find(k,"+") then
                    key = (string.gsub(k,"+","."))                            
                end
            end
            if type(v)=="string" then
                if v=="" then
                    break;
                end
            end            
            if type(v)=="table" and v[1]=="" then
                break
            end
            if self:is_use_slot_index() then
                result[key] = v
            else
                result[key] = v[1]
            end
            
            if pinyin_soundex_slot[key] then                 
                local raw
                key = key.."_pinyin"
                if self:is_use_slot_index() then
                    result[key] = {}
                    raw,result[key][1]=self:gsub_wordstring_wtk(input,v[1],v[2],v[3])
                    result[key][2] = -1
                    result[key][3] = -1
                else
                    raw,result[key]=self:gsub_wordstring_wtk(input,v[1],v[2],v[3])
                end
            end         
        end        
    end                    
    return result
end

function M:reform_tokens_with_old_format( input, tokens )    
    local result = {}
    local slots
    local cnt
    
    cnt = 0    
    for k,v in pairs(tokens) do        
        slots = self:reform_slot_with_old_format(input,v)
        for k1,v1 in pairs(slots) do
            result[k1]=v1;
            cnt = cnt + 1;
        end        
    end    
    return result,cnt
end

function M:reform_output_with_old_format( data, output )    
    local result = {} 
--{"semantics":{"request":{"slotcount":3,"domain":"音乐","action":"音乐","param":
--{"操作":["上一首",0,2],"__act__":["inform",-1,-1],"对象":["音乐",3,3]}}},
--"version":"2017.4.26.09:32:44","systime":161.78198242188,"input":"上一首歌","res":"aihome.0.14.1"}
    result = {}
    result.request = {}    
    result.request.domain = data.domain
    if data.dlg_domain and data.dlg_domain ~= "@" and data.jump_domain ~= "@" then
        result.request.jumpdomain = data.domain
    end
    result.request.action = data.domain
    result.request.param = {}

    if output.nTokens > 0 and output.tokens then
        result.request.param,result.request.slotcount = self:reform_tokens_with_old_format(data.input, output.tokens)
    else
        result.request.param = {}
        result.request.slotcount = 0
    end
        
    --[[
    if output.nTokens > 1 then
        result.semantics.nbest = {}        
        for i=2,output.nTokens do
            local request = {}
            request.request = {}
            request.request.domain = data.domain
            request.request.action = data.domain
            request.request.param = {}
            if output.tokens[i] ~= nil then
                request.request.param,slotcnt = self:reform_tokens(data.input, output.tokens[i])
                request.request.slotcount = slotcnt
                table.insert(result.semantics.nbest,request)
            end
        end
    end
    --]]
    return result
end

function M:reform_output_with_wtk_format(data,output,nbest)    
    local ret
    
    ret = {}        
    ret.version = core:get_version();
    ret.systime = data.time
    ret.res     = data.res
    ret.input   = data.input_str
    --{"input":"20点","res":"aihome.0.14.1","version":"2017.4.26.09:32:44","systime":225.85400390625}
    if data.domain and data.domain ~= "@" then
        ret.semantics = {} 
        ret.semantics = self:reform_output_with_old_format(data,output)
        if nbest and table.maxn(nbest) > 0 then
            local has_nbest = false
            ret.semantics.nbest ={}        
            for k,v in pairs(nbest) do                
                data.domain = data.nbest[k].domain
                local tmp =self:reform_output_with_old_format(data,v)
                table.insert(ret.semantics.nbest,tmp)                                    
            end            
        end
    end
    return ret
end
    

--data.skill  ==> skill name
--data.domain ==> current domain
--data.time   ==> process time
--data.res    ==> res defined in cfg
--data.input  ==> processor input
function M:reform_output( data, output )
    local slotcnt = 0
    local result = {}
    
--input format {"slots":[{"__WEIGHT__":0.8,"__RE_END__":0,"__SLOT_END__":6,"__RE_START__":6,"联系人":"刘洪彬"}],"slot_num":1}
--output format {"skill":"SK_1","semantics":{"request":{"slotcount": 2,"task": "打电话","slots":[{"name":"intent","value": "打电话"},{"name": "联系人","value": "习近平","rawvalue": "习大大","pos": [4,6 ], "rawpinyin": "xi da da"}] } }, "version": "2017.2.13.16:38:28", "systime": 17.782958984375, "input": "打电话给习大大", "res": "aicar.0.8.16"}

    data.domain = string.gsub(data.domain,"+",".")
    
    result.skill = data.skill
    result.semantics = {}    
    result.semantics.request ={}
    result.semantics.request.domain = data.domain
    if data.dlg_domain and data.dlg_domain ~= "@" and data.jump_domain ~= "@" then
        result.semantics.request.jumpdomain = data.domain
    end
    if data.confidence then
        result.semantics.request.confidence = data.confidence
    end
    result.semantics.request.slots = {}

    if output.tokens ~= nil then
        result.semantics.request.slots,slotcnt = self:reform_tokens(data.input, output.tokens)
    end
    result.semantics.request.slotcount = slotcnt
    result.version = core:get_version()
    result.systime = data.time
    result.res     = data.res
    result.input   = data.input_str
    
    if output.nTokens > 1 then
        result.semantics.nbest = {}        
        for i=2,output.nTokens do
            local request = {}
            request.request = {}
            request.request.task = data.domain
            request.request.slots = {}
            if output.tokens[i] ~= nil then
                request.request.slots,slotcnt = self:reform_tokens(data.input, output.tokens[i])
                request.request.slotcount = slotcnt
                table.insert(result.semantics.nbest,request)
            end
        end
    end
    return result
end

function M:reform_domain_output( data, domain, nbest )
    local ver = require("utils.version")
    local slotcnt = 0
    local result = {}
    local i,slots;
    
    if domain then
        domain = string.gsub(domain,"+",".")
    end
    
    if data.domain then
        data.domain = string.gsub(data.domain,"+",".")
    end
    
    if data.dlg_domain then
        data.dlg_domain = string.gsub(data.dlg_domain,"+",".")
    end
    
    if nbest then
        for i=1,table.maxn(nbest) do
            nbest[i].domain = string.gsub(nbest[i].domain,"+",".")
        end
    end
           
    result.skill = data.skill

    if domain then
        result.semantics = {}    
        result.semantics.request ={}            
        result.semantics.request.task = domain
        result.semantics.request.slots = {}
        if data.dlg_domain and data.dlg_domain ~= "@" then
            if data.weight > 0 then
                result.semantics.request.jumptask = domain
            end
        end
     
        if nbest then
            local num
            num = table.maxn(nbest)
            if num > 0 then        
                result.semantics.nbest = {}        
                for i=1,table.maxn(nbest) do
                    local request = {}
                    request.request = {}
                    --request.request.task = data.domain
                    --request.request.slots = {}
                    request.request.task = nbest[i].domain
                    request.request.slots = {}
                    if data.dlg_domain and data.dlg_domain ~= "@" then
                        request.request.jumptask = nbest[i].domain
                    end
                    table.insert(result.semantics.nbest,request)
                end
            end
        end    
    end
    --result.semantics.request.slotcount = slotcnt
    result.version = core:get_version()
    result.systime = data.time
    result.res     = data.res
    result.input   = data.input_str
    
    return result
end

--************************************************************************--
--                             merge functions                            --
--************************************************************************--
function M:get_start_pos( value )
    local ret
    if table.maxn(value) == 3 then
        ret = value[2]
    else
        ret = value[1]
    end
    return ret
end

function M:get_end_pos( value )
    local ret
    if table.maxn(value) == 3 then
        ret = value[3]
    else
        ret = value[2]
    end
    return ret
end

function M:get_key_in_slot(slot)
    local key
    key = slot.__KEY__    
    --[[
    for k,v in pairs(slot) do
        if k ~= "__WEIGHT__" and k ~= "__RE_START__" and k ~= "__RE_END__" and k~= "__SLOT_START__" and k~= "__SLOT_END__" then
            key = k
        end
    end
    if not key then
        print("error: can not find key in token")
    end 
    --]]
    return key
end

function M:get_first_slot(slots)
    local slot
    local key
    for i, v in pairs(slots) do
        slot = v
        key = i
        break
    end
    return slot,key
end    
        
function M:merge_by_key(slots)
    local ret = {}
    local slot = {}
    local key,i
    local weight = 0
    local delcnt = 0

    local slotcnt = table.maxn(slots)
    while slotcnt > 0 
    do
        slot,i = self:get_first_slot(slots)             
        key = self:get_key_in_slot(slot)                
        if slot.__WEIGHT__ then
            weight = slot.__WEIGHT__
        else
            weight = 0
        end
        for k,v in pairs(slots) do            
            if v[key] then                                            
                if v.__WEIGHT__ then
                    if weight < v.__WEIGHT__ then                    
                        slot = v
                        weight = v.__WEIGHT__
                    else                        
                        if weight == v.__WEIGHT__ then                            
                            if type(slot[key]) == "table" and type(v[key])== "table"then
                                if table.maxn(slot[key]) < 3 then
                                    if table.maxn(v[key]) >=3 then                                    
                                        slot = v
                                    end
                                else
                                    if table.maxn(slot[key]) == 3 and table.maxn(v[key]) == 3 then                                        
                                        if slot[key][3]-slot[key][2] < v[key][3]-v[key][2] then                                            
                                            slot = v
                                        else
                                            if slot[key][3]-slot[key][2] == v[key][3]-v[key][2] then   
                                                if type(slot[key][1])=="string" and type(v[key][1])=="string" then                                                                                                
                                                    if string.len(slot[key][1]) < string.len(v[key][1]) then
                                                        slot = v
                                                    else
                                                        if string.len(slot[key][1]) == string.len(v[key][1]) then
                                                            if slot[key][1] < v[key][1] then                                    
                                                                slot = v
                                                            end
                                                        end
                                                    end
                                                end
                                            end    
                                        end
                                    end
                                end
                            elseif type(slot[key]) == "string" and type(v[key])== "string"then
                                if string.len(slot[key][1]) < string.len(v[key][1]) then
                                    slot = v
                                else
                                    if string.len(slot[key][1]) == string.len(v[key][1]) then
                                        if slot[key][1] < v[key][1] then                                    
                                            slot = v
                                        end
                                    end
                                end             
                            end                            
                        end
                    end
                end
            slots[k] = nil
            delcnt = delcnt + 1
            end
        end
        slotcnt = slotcnt - delcnt
        delcnt = 0
        if slot[slot.__KEY__][1] ~= "" then        
            slot.__KEY__ = nil        
            table.insert(ret,slot)
        end                        
    end    
    return ret
end

function M:find_value_in_slot(slot)
    local ret
    for k,v in pairs(slot) do
        if type(v) == "table" then
            if table.maxn(v) > 0 then
                ret = v
            end
        end
    end
    return ret
end

function M:is_in_range(v1, v2)
    local ret = false
    if self:get_start_pos(v1) < self:get_start_pos(v2) and self:get_end_pos(v1) >= self:get_end_pos(v2) then
        ret = true
    else
        if self:get_start_pos(v1) <= self:get_start_pos(v2) and self:get_end_pos(v1) > self:get_end_pos(v2) then
            ret = true
        end
    end
    return ret
end

function M:is_same_ranage(v1, v2)
    return self:get_start_pos(v1) == self:get_start_pos(v2) and self:get_end_pos(v1) == self:get_end_pos(v2)
end
        

function M:merge_by_raw_value(slots)
    local slot_start,slot_end
    local slotcnt,slot,value,weight,delcnt,i,vidx
    local ret = {}
    
    slotcnt = table.maxn(slots)
    delcnt = 0
    while slotcnt > 0
    do
        slot,i = self:get_first_slot(slots)
        value = self:find_value_in_slot(slot)
        
        if slot.__WEIGHT__ then
            weight = slot.__WEIGHT__
        else
            weight = 0
        end
                
        if value and type(value)=="table" and value[2] ~=-1 and value[3] ~= -1 then        
            for k,v in pairs(slots) do
                local tmp = {}
                local tidx
                local is_keep = -1                
                tmp = self:find_value_in_slot(v)
                if tmp and type(tmp)=="table" and #tmp==3 then                    
                    if self:is_in_range(tmp,value) then -- value被tmp包含则丢弃value
                        is_keep = 1                       
                    else                       
                        if self:is_in_range(value,tmp) or k==i then -- tmp被value包含则丢弃tmp
                            is_keep = 0
                        else
                            if v.__WEIGHT__ and self:is_same_ranage(value,tmp) then -- tmp与value的位置相同
                                is_keep = -1;
                            --[[
                                if v.__WEIGHT__ > weight then
                                    is_keep = 1
                                else
                                    if v.__WEIGHT == weight then
                                        is_keep = 1
                                    else
                                        is_keep = 0
                                    end                                                                
                                end
                                --]] 
                            end                           
                        end            
                    end
                    if is_keep == 1 then
                        slot = v
                        value = self:find_value_in_slot(slot)
                        if slot.__WEIGHT__ then
                            weight = slot.__WEIGHT__
                        else
                            weight = 0
                        end
                        slots[k] = nil
                        delcnt = delcnt + 1
                    end
                    if is_keep == 0 then
                        slots[k] = nil
                        delcnt = delcnt + 1
                    end
                end
            end            
            table.insert(ret,slot)                            
        else
            table.insert(ret,slot)            
            slots[i] = nil            
            delcnt = delcnt + 1            
        end
        slotcnt = slotcnt - delcnt
        delcnt = 0
    end
    
    return ret
end 

function M:merge_tokens( output )
    local wslots = {}
    local weight 
    
    if output.nTokens < 2 then
        return output
    end
    
    for i=1,table.maxn(output.tokens) do
        --if output.tokens[i].__WEIGHT__ then
        --    weight = output.tokens[i].__WEIGHT__
        --else
        --    weight = 0
        --end        
        for k, v in pairs(output.tokens[i]) do            
           if k ~= "__WEIGHT__" and k ~= "__RE_START__" and k~= "__RE_END__" and k~="__KEY__" and k~="__NAME__" and k~="__SEQ__" and k~="__ID__" then
                local tmp = {}
                tmp.__WEIGHT__ = output.tokens[i].__WEIGHT__  
                tmp.__KEY__ = k              
                if type(v)=="string" then
                    tmp[k]={[1]=v,[2]=-1,[3]=-1}
                else
                    tmp[k] = v
                end                 
                table.insert(wslots,tmp)                
            end        
        end
    end
       
    if wslots then          
        wslots = self:merge_by_key(wslots)
    end
        
    if wslots then        
        wslots = self:merge_by_raw_value(wslots)
    end
    
    output.nTokens = 1
    output.tokens = {}
    for i = 1, table.maxn(wslots) do
      table.insert(output.tokens, wslots[i])
    end    
    return output
end

--************************************************************************--
--                            pinyin functions                            --
--************************************************************************--
function M:set_pinyin(pinyin)
    self.pinyin.input = pinyin
end

function M:set_pinyin_soundex_slot( data )
    pinyin_soundex_slot = data
end

local engine = require "engine.pinyin"
local egn = nil
function M:get_slot_pinyin_from_db( input, spos, epos )
    local output
    
    if not egn then
        --print("new pinyin engine")
        egn = engine.new(self.pinyin.cfg,self.pinyin.pwd)
    end
    
    egn:feed(input)
    
    output = egn:get_result();    
    
    egn:reset()
--    egn = nil

    return output
end

function M:split(s, delim)
    if type(delim) ~= "string" or string.len(delim) <= 0 then
        return
    end
    local start = 1
    local t = {}
    while true do
        local pos = string.find (s, delim, start, true) -- plain find
        if not pos then
          break
        end
        table.insert (t, string.sub (s, start, pos - 1))
        start = pos + string.len (delim)
    end
    table.insert (t, string.sub (s, start))    
    return t
end

function M:get_slot_pinyin_from_input(input,spos,epos)    
    local pinyin_array,py_value
    pinyin_array = self:split(input," ")
    py_value=""
    for i=spos+1,epos do
        py_value = py_value..pinyin_array[i-spos].." ";    
    end
    py_value = py_value..pinyin_array[epos-spos+1];
    return py_value
end

function M:attach_slot_pinyin(input,spos,epos)
    local ret
    if self.pinyin.input then
        if self.pinyin.input ~="@" and self.pinyin.input ~= "" then
            ret = self:get_slot_pinyin_from_input(self.pinyin.input,spos,epos)
        else
            --ret = self:get_slot_pinyin_from_db(input,spos,epos);
            ret = self:get_slot_pinyin_from_db(input,1,string.len(input))
        end
    else
        --ret = self:get_slot_pinyin_from_db(input,spos,epos);
        ret = self:get_slot_pinyin_from_db(input,1,string.len(input))
    end
    return ret
end

return M
