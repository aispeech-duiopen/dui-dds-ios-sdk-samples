require("utils.base")
local M = {}

M.opts = {}
M.filter_patterns = {}

M.wakeup = {
    word = "",
    common = {
        word    = "",
        pingyin = "",
    },
    custom = {
        word    = "",
        pingyin = "",
    }
}

local txt = require("utils.txt")

function M:set_fileter( patterns )
    self.filter_patterns = patterns
end

function M:set_wakeup_word( wakeup )
    if wakeup.word then
        self.wakeup.word = wakeup.word
    end
    if wakeup.common then
        if wakeup.common.word then
            self.wakeup.common.word = wakeup.common.word
        end
        if wakeup.common.pinyin then
            self.wakeup.common.pinyin = wakeup.common.pinyin
        end
    end 
    if wakeup.custom then
        if wakeup.custom.word then
            self.wakeup.custom.word = wakeup.custom.word
        end
        if wakeup.custom.pinyin then
            self.wakeup.custom.pinyin = wakeup.custom.pinyin
        end
    end
end

function M:remove_wakeup_words(input)
    if self.wakeup and self.wakeup.word then
        input = string.gsub(input,self.wakeup.word,"",string.len(self.wakeup.word))
    elseif self.wakeup.custom.word then
        input = string.gsub(input,self.wakeup.custom.word,"",string.len(self.wakeup.custom.word))
    elseif self.wakeup.common.word then
        input = string.gsub(input,self.wakeup.common.word,"",string.len(self.wakeup.common.word))
    end    
    return input    
end    

    
function M:filter(input)
    local core = require("engine.core")
    local i, s, e, num, b;
    local patterns, n_patterns;
    local wordstr, output = ""
            
    patterns = self.filter_patterns;
    n_patterns = table.maxn(patterns);
        
    s = 1;
    e = s + string.len(input);
    while (s < e) 
    do
        num = core:utf8_bytes(string.sub(input,s));        
        b = 1;
        if (num == 1 and (string.byte(input,1) == 0x09 or string.byte(input,1) == 0x0a)) then
            s = s + num;            
        else
            i=1;
            while(i <= n_patterns)
            do
                if ( patterns[i] == string.sub(input,s,s+num-1) ) then
                    b = 0;
                    break;
                end
                i=i+1;
            end
            
            if (b == 1) then
                 wordstr = string.sub(input,s,s+num-1);
                 if output then
                     output = output..wordstr
                 else
                     output = wordstr
                 end
            end
            s =s + num;
        end
    end
    return output
end

function M:pre_processor(input)
    local str
    local output    
    
    str = txt:remove_space(input)
    
    if (self.filter_patterns) then
        str = self:filter(str) 
    end

    if not str then
        str = input
    end

    output = self:remove_wakeup_words(str)    
    
    return output,str
end

return M
