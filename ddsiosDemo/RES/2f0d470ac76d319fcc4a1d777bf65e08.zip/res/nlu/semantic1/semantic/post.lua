require("utils.base")
local M = {}
M.opts = {}
M.post_func = nil
M.wtk_format = false

function M:init( func )
    self.post_func = func
end

function M:is_use_slot_index()
    local ret = false;
    if self.opts then
        if self.opts.use_slot_index then
            ret = self.opts.use_slot_index
        end
    end
    return ret
end

function M:post_request_process(k,attr)
    local str,func,ret1,ret2;
    str = "pub_actpls"..k;
    --print(str)
    func = self.post_func[str];
    if( func == nil ) then    
        print("can't find function:",k,"=============================================")
        return k;
    end
    ret1,ret2 = func(self.post_func, attr);
    
    if type(ret2) ~= "string" then
        ret2 = tostring(ret2)
    end
    
    return ret2;
end

function M:get_key_index( key )
    local str
    local ret
    
    str = string.match(key, ".+@([^@]%d*)$")
    
    if not str then
        str = "0"
    end
 
    ret = tonumber(str)
    if not ret then
       ret = 0
    end

    return ret
end

function M:get_key_prefix( key )
    --str = string.match(key, "(.+)_[^_]%d*$")
    return string.match(key, "(.+)@[^@]%d*$")
end
    
function M:is_normalization(key)
    local ret = false 
    if type(key) == "string" then
        if string.len(key) > 1 then
            if  string.byte(key,1) == 0x40 then -- '@' = 0x40
                if string.byte(key,2) > 0x30 and string.byte(key,2) < 0x40 then -- 0x31 = '1' and 0x39 = '9'
                    ret = true
                end
            end
        end
    end
    return ret    
end  

function M:normalize_value(data)
    local value = ""
    local sort = {}
    local key_tbl = {}
    local tmp = {}
    
   
    for k, v in pairs(data) do                    
        if k == "__SLOT_START__" then
            tmp[2] = v
        elseif  k == "__SLOT_END__" then
            tmp[3] = v
        else   
            local key
            if type(v) == "string" then                                          
                key = self:get_key_index(k)
                sort[key] = v                        
                table.insert(key_tbl,key)                                
            end
        end
    end

    table.sort(key_tbl)

    for idx, val in pairs(key_tbl) do
        if value then
            value = value..sort[val]            
        else
            value = sort[val]
        end    
    end
    tmp[1] = value
    if table.maxn(tmp) == 1 then
        ret = tmp[1]
    else
        ret = tmp
    end
     
    return ret
end

function M:concatenate_value(data)
    local value,key_idx
    local prefix_tbl = {}
    local same_prefix_data ={}
    local tmp = {}
    local cnt = 0
    local pos = {}
        
    for k, v in pairs(data) do                    
        if k == "__SLOT_START__"  or  k == "__SLOT_END__" then
            pos[k]=v
        else
            if not value then
                value = v
                key_idx = self:get_key_index(k)
            else
                if key_idx > self:get_key_index(k) then
                    key_idx = self:get_key_index(k)
                    value = v
                end
            end   
            local prefix
            if type(v) == "string" then                                          
                prefix = self:get_key_prefix(k)                 
                if prefix then
                    if not prefix_tbl[prefix] then
                        prefix_tbl[prefix] = {}
                    end
                    table.insert(prefix_tbl[prefix],k)
                end                                                
            end
        end
        if pos["__SLOT_START__"] then
            table.insert(tmp,pos["__SLOT_START__"])
            cnt = cnt + 1
        end
        if pos["__SLOT_END__"] then
            table.insert(tmp,pos["__SLOT_END__"])
            cnt = cnt + 1
        end                                    
    end
    
    local prefix_cnt = 0
    for k,v in pairs(prefix_tbl) do
        if table.maxn(v) > 1 then
            for idx,val in pairs(v) do
                same_prefix_data[v[idx]] = data[v[idx]]
            end
            prefix_cnt = prefix_cnt + 1
            value = self:normalize_value(same_prefix_data)            
            if prefix_cnt >= 2 then
                print("error: more than one prefix group")
            end
        end
    end    
        
    table.insert(tmp,value)
    if cnt == 0 then
        ret = tmp[1]
    else
        ret = tmp
    end
    return ret
end

--1. 从最里层的table开始处理
--2. table里有post keyword就做变量function处理求值
--3. [value, slot_start, slot_end]
--4. 如果table返回值为nil,需要将这一层的string做合并
function M:process_inline_slots(data, normalize)
    local index,str,num,hastable
    local isnormalize = false
    
    hastable = false
    index = 0    
    if self.wtk_format then
        if data.__act__ and type(data.__act__) == "string"  then               
            data.__SLOT_START__ = -1
            data.__SLOT_END__   = -1
        end
    end
    for i, v in pairs(data) do
        --isnormalize = self:is_normalization(i)
        --isnormalize = isnormalize or normalize  
        if type(v) == "table" then
            hastable = true
            str,num = self:process_inline_slots(v, normalize)                -- 从最里层的开始处理
            data[i]=str            
        end
        index = index + 1;
    end
    
    if( data["__POST__"]~=nil ) then                    -- 如果table里有post则生成一个字符串数据返回
        str = self:post_request_process(data["__POST__"], data );
    end      

    if not str then --{}里没有table（不再有嵌套）,也没有post
        if index == 1 then
            for i,v in pairs(data) do 
                str = v
            end
        else            
            if normalize then
                str = self:normalize_value(data)          
            --else
             --   str = self:concatenate_value(data)
            end
        end
    else
        if index == 1 then
            for i,v in pairs(data) do 
                str = v
            end
        else    
            if not data["__POST__"] then                
                if normalize then
                    str = self:normalize_value(data)
                --else                    
                --    str = self:concatenate_value(data)
                end
            end
        end
    end     
       
    return str,index
end

function M:process_token(s)
    local tmp;
    local str;
    local num;
    local pos = {};
    
    for k, v in pairs(s) do
        if type(v) == "table" then             
            str,num = self:process_inline_slots(v,true);            
            if num == 1 then
                if str ~= nil then  --如果string中没有post,str为null
                    if type(str) == "table" then
                        if table.maxn(srt) > 0 then
                            s[k] = str                            
                        else
                            s[k] = nil
                        end
                    else
                        s[k] = str
                    end
                else
                    s[k] = str
                end
            else 
                if type(str) == "string" then
                    s[k] = str
                else
                    local slot_not_processed = false
                    local value
                    tmp = {}                 
                              
                    for k1,v1 in pairs(v) do
                        if k1 == "__SLOT_START__"  or  k1 == "__SLOT_END__" then
                            slot_not_processed = true
                            pos[k1]=v1
                        else
                            value = str[1]                        
                        end
                    end

                    --数组的内容的顺序需为value,slot_start,slot_end
                    if value then
                        tmp[1] = value
                    else
                        tmp[1] = ""
                    end
                    if pos["__SLOT_START__"] then
                        tmp[2] = pos["__SLOT_START__"]
                    end
                    if pos["__SLOT_END__"] then
                        tmp[3] = pos["__SLOT_END__"]
                    end                
                    if slot_not_processed then                   
                        s[k] = tmp
                    else                    
                        s[k] = str[1]
                    end
                end
            end
        else
            if self.wtk_format then           
                if s.__act__ and type(s.__act__) == "string" then
                    tmp = {}
                    table.insert(tmp,s.__act__)
                    table.insert(tmp,-1)
                    table.insert(tmp,-1)
                    s.__act__ = tmp
                end
            end
        end
    end
        
end

function M:process_token_array(data)            
    local num = data.nTokens 
    local var = data.tokens
    
    for i=1,num do
        if var[i] then  
          self:process_token(var[i])
        end
    end
end

function M:find_first_slot_pos(token)
    local spos, epos, key
    for k,v in pairs(token) do
        if type(v) == "table" then
            if v.__SLOT_START__ then
                if not spos then
                    spos = v.__SLOT_START__
                    epos = v.__SLOT_END__
                    key = k
                else
                    if spos > v.__SLOT_START__ then
                        spos = v.__SLOT_START__
                        epos = v.__SLOT_END__
                        key = k
                    end
                end
            end
        end
    end
    return key,spos,epos
end

function M:find_next_slot_pos(tokne, last_epos )
    local spos, epos, key
    spos = last_epos
    for k,v in pairs(token) do
        if type(v) == "table" then
            if v.__SLOT_START__ then
                if not spos and v.__SLOT_START__ > last_epos then
                    spos = v.__SLOT_START__
                    epos = v.__SLOT_END__
                    key = k
                else
                    if spos > v.__SLOT_START__ and v.__SLOT_START__ > last_epos then
                        spos = v.__SLOT_START__
                        epos = v.__SLOT_END__
                        key = k
                    end
                end
            end
        end
    end
    return key,spos,epos
end

function M:merge_tokens_by_order(tokens)
    local spos, epos, key
    local tmp_spos,tmp_epos,tmp_key    
    local last_epos
    local index
    local ret    
    
    for k, v in pairs(tokens) do
        tmp_key,tmp_spos,tmp_epos = self:find_first_slot_pos(v)        
        if not spos then                           
            key = tmp_key
            spos = tmp_spos
            epos = tmp_epos            
        else            
            if tmp_spos and spos > tmp_spos then
                    spos = tmp_spos
                    epos = tmp_epos
                    key = tmp_key
                    index = k                
            end
        end
    end
    
    if not spos then
        return tokens[1]
    end
    
    local tmp1 = {}
    local cnt
    cnt = 0
    for k1, v1 in pairs(tokens) do
        if v1.__SLOT_START__ == spos then
            table.insert(tmp1,v1)
            cnt = cnt + 1
        end
    end    
    
    while cnt > 1
    do
        last_epos = epos
        spos = nil
        epos = nil
        for k2, v2 in pairs(tokens) do
            tmp_key,tmp_spos,tmp_epos = self:find_next_slot_pos(tmp1,last_epos)
            if not spos then                           
                key = tmp_key
                spos = tmp_spos
                epos = tmp_epos            
            else
                if not tmp_spos and spos > tmp_spos then
                    spos = tmp_spos
                    epos = tmp_epos
                    key = tmp_key
                    index = k2
                end
            end
        end
        
        cnt = 0
        local tmp2 = {}
        for k3, v3 in pairs(tmp1) do
            if v3.__SLOT_START__ == spos then
                table.insert(tmp2,v3)
                cnt = cnt + 1
            end
        end        
        tmp1 = tmp2
    end
    
    if index then    
        ret = tokens[index]
    else
        ret = tokens[1]
    end
    --print("order===================================")
    --table.print(ret)
    return ret
end

function M:merge_token_by_range(tokens)
    local match_rule_range = 0
    local tmp = {}
    local cnt
    local ret
    cnt = 0
    
    for k,v in pairs(tokens) do
        if v.__RE_END__ and v.__RE_START__ then
            if v.__RE_END__ - v.__RE_START__ > match_rule_range then
                match_rule_range = v.__RE_END__ - v.__RE_START__
            end
        else
            print("error =====================================================")
            table.print(v)
        end
    end
    
    for k1,v1 in pairs(tokens) do
        if v1.__RE_END__ - v1.__RE_START__ == match_rule_range then
            table.insert(tmp,v1)
            cnt = cnt + 1
        end
    end
    
    if cnt > 1 then
        ret = self:merge_tokens_by_order(tmp)
    else
        ret = tmp[1]
    end
    --print("range =========================================")
    --table.print(ret)
    return ret        
end

function M:merge_tokens(data)
    local id_tbl = {}
    local key
    local output = {}        
    
    output.nTokens = 0
    output.tokens = {}
    
    for i=1, data.nTokens do
        if data.tokens[i] then
            key = data.tokens[i].__ID__
            id_tbl[key] = key 
        end
    end
    
    for k,v in pairs(id_tbl) do        
        local tmp = {}       
        for k1,v1 in pairs(data.tokens) do
            if v == v1.__ID__ then
                v1.__ID__ = nil
                if v1.__RE_END__ == -1 then
                    --print("error ==================================================")
                    --table.print(v1)
                    v1.__RE_END__ = v1.__RE_START__
                end                
                table.insert(tmp,v1)
                data.tokens[k1] = nil
            end
        end
        --print("start merge by id-------------------------------------------------")
        --table.print(tmp)
        local tmp2        
        tmp2 = self:merge_token_by_range(tmp)
        --print(k,"end merge by id-------------------------------------------------")
        --table.print(tmp2)        
        table.insert(output.tokens,tmp2)
        output.nTokens = output.nTokens + 1                
    end
    --print("merge")
    --table.print(output)
    --output.nTokens = table.maxn(output.tokens)
    return output    
end
-- 一句话可以分成几段话都匹配到同一个规则都成功,因为所有匹配成功的输出slot name/key是相同的,这样状况需要做特别处理,这个规则的merge需要特别在这个表中描述做特殊处理.
function M:remove_slot_with_same_key_in_tokens(key,tokens)    
    local next_pos
    local idx ={}
    local ret ={}
    
    while idx 
    do
        local slot_start = -1
        local slot_end = -1
        idx = nil        
        for k,v in pairs(tokens) do            
            if v[key] and type(v[key]) == "string" then
                v[key] = { [1] = v[key], [2] = -1, [3] = -1 }
            end

            if v[key][2] == -1 and v[key][3] == -1 then
                table.insert(ret,tokens[k])
                tokens[k] = nil
            else       
                if next_pos and v[key][2] < next_pos then
                    tokens[k] = nil
                else                         
                    if slot_start == -1 then
                        slot_start = v[key][2]
                        slot_end = v[key][3]
                        idx = k                
                    elseif slot_start > v[key][2] then
                        slot_start = v[key][2]
                        slot_end = v[key][3]
                        idx = k
                    elseif slot_start == v[key][2] then
                        if slot_end < v[key][3] then
                            slot_end = v[key][3]
                            idx = k
                        end
                    end                
                end
            end
        end        
        
        if slot_end ~=-1 then
            next_pos = slot_end + 1
        end

        if idx then
            table.insert(ret,tokens[idx])
            tokens[idx]=nil
        end
    end
    
    return ret                
end

local tokens_to_merge = {}
function M:set_sp_rule( data )
     tokens_to_merge = data
end

local function data_cmp(a,b)
    return a[2]<b[2]
end

local function get_slot_list(t)
    local list = {}
    local cnt = 0
    for k, v in pairs(t) do
        if k ~= "__ID__" and k ~= "__NAME__" and k ~= "__SEQ__" and k ~= "__RE_START__" and k ~= "__RE_END__" and k ~= "__WEIGHT__" then
            if type(v) == "table" then                
                cnt = cnt+1
                v.key = k
                list[cnt] = v
            end
        end
    end    
    if cnt > 1 then
        table.sort(list,data_cmp)
    elseif cnt == 0 then
       list = nil
    end   
    return list
end

local function cmp_list(sl1,sl2)
    local ret = false        
    
    for k, v in pairs(sl1) do        
        if not sl2[k] then
            ret = true
            break
        end

        if sl1[k][1] == "__NIL__" and sl2[k][1] ~= "__NIL__" then
            ret = false
            break
        elseif sl1[k][1] ~= "__NIL__" and sl2[k][1] == "__NIL__" then
            ret = true
            break
        end

        if sl1[k].key ~= sl2[k].key then
            ret = false
            break
        else        
            if sl1[k][2] < sl2[k][2] then
                ret = false
                break
            elseif sl1[k][2] == sl2[k][2] then
                if sl1[k][3] > sl2[k][3] then
                    ret = true
                    break
                elseif sl1[k][3] < sl2[k][3] then
                    ret = false
                    break
                end
            elseif sl1[k][2] > sl2[k][2] then
                ret = false
                break
            end
        end
    end
    return ret;    
end

local function cmp_tokens( t1, t2 )
    local ret,skip
    local slot_list1,slot_list2
    slot_list1 = get_slot_list(t1)
    slot_list2 = get_slot_list(t2)
    skip = false
    if not slot_list1 or not slot_list2 then       
        ret = false
        skip = true
    elseif table.maxn(slot_list1) == 1 and slot_list1[1].key == slot_list2[1].key then        
        if slot_list1[1][1] == "__NIL__"  and slot_list2[1][1] ~= "__NIL__"then
            ret = false
            skip = false
        elseif slot_list2[1][1] == "__NIL__"  and slot_list1[1][1] ~= "__NIL__"then
            ret = true
            skip = false
        elseif slot_list1[1][2] < slot_list2[1][2] and slot_list1[1][3] >= slot_list2[1][2] then
            ret = true
            skip = false
        elseif slot_list2[1][2] < slot_list1[1][2] and slot_list2[1][3] >= slot_list1[1][2] then
            ret = false
            skip = false
        elseif slot_list1[1][2] > slot_list2[1][3] or slot_list2[1][2] > slot_list1[1][3] then
            ret = false
            skip = true
        elseif slot_list1[1][2] < slot_list2[1][2] and slot_list1[1][3] >= slot_list2[1][3] then
            ret = true
            skip = false
        elseif slot_list2[1][2] < slot_list1[1][2] and slot_list2[1][3] >= slot_list1[1][3] then
            ret = false
            skip = false
        elseif slot_list1[1][2] == slot_list2[1][2] and slot_list1[1][3] == slot_list2[1][3] then
            ret = false
            skip = false
        else
            skip = true
        end
    else
        if table.maxn(slot_list1) == table.maxn(slot_list2) then
            ret = cmp_list(slot_list1,slot_list2)
        elseif table.maxn(slot_list1) > table.maxn(slot_list2) then
            ret = true
        else
            ret = false
        end
    end
    return ret,skip
end
    
function M:post_processor(domain,data)  
    local output = {}    
          
    self:process_token_array(data); 
     
    output.nTokens = 0
    output.tokens = {}
    --output = self:merge_tokens(data);
    --output = data
    --移除同一个规则生成的相同的tokens结果    
    for k,v in pairs(data.tokens) do
        local is_same = false;
        for k1, v1 in pairs(output.tokens) do            
            for key,value in pairs(v) do
                if type(value)=="table" and type(v1[key])=="table" then
                    if value[1] == v1[key][1] and value[2] == v1[key][2] and value[3] == v1[key][3] then
                        is_same = true
                    else
                        is_same = false
                        break
                    end
                else
                    if value == v1[key] then                    
                        is_same = true
                    else                        
                        is_same = false
                        break
                    end
                end
            end
        end
        
        if not is_same then
            if tokens_to_merge[domain..":"..v.__NAME__] then
                table.insert(tokens_to_merge[domain..":"..v.__NAME__].tokens,v)
            else
                local has_same_len_rule = false
                for k2, v2 in pairs(output.tokens) do
                    if v2.__NAME__ == v.__NAME__ then
                        if v2.__SEQ__ == v.__SEQ__ and v2.__RE_START__ == v.__RE_START__ and v2.__RE_END__ == v.__RE_END__ then
                        --if v2.__SEQ__ == v.__SEQ__ then
                            local replace = false
                            local skip
                            has_same_len_rule = true
                            replace,skip = cmp_tokens(v,v2)
                            if skip then
                                has_same_len_rule = false
                            elseif replace then
                                --print("replace")
                                --table.print(output.tokens[k2])
                                output.tokens[k2] = v
                            --else
                            --    print("ignore")
                            --    table.print(v)
                            end
                        end
                        --if v2.__SEQ__ ~= v.__SEQ__ then
                        --    v.__NAME__ = v.__NAME__..'@'..tostring(v.__SEQ__)
                        --end
                    end                        
                end
                if not has_same_len_rule then
                    table.insert(output.tokens,v)
                    output.nTokens = output.nTokens+1                
                end
            end
        end     
    end
             
    for k,v in pairs(tokens_to_merge) do
        local tmp        
        if table.maxn(v.tokens) > 0 then
            tmp = self:remove_slot_with_same_key_in_tokens(v.key,v.tokens)
            
            for k1,v1 in pairs(tmp) do
                table.insert(output.tokens,v1)
                output.nTokens = output.nTokens+1
            end
        end        
    end
    return output
end

return M
