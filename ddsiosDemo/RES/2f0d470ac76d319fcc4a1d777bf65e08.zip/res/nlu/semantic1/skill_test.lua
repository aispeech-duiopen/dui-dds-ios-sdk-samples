--package.cpath = "/home/aisp/project/lex/semantic_v3/.libs/semantic.so"
package.cpath = "./tool/libs/semantic.so"
package.path = "./tool/semantic_lua/src/?.lua;./tool/semantic_lua/src/semantic/?.lua;"

local nluflow = require 'nluflow'
local json    = require 'utils.json'

local skill_path = "./skill"
local skill_cfg_name = "config.json"
local skill_id_table = {
    ["新闻"] = "100000283/1",
    ["股票"] = "100000280/1",
    ["电台"] = "100000279/1",
    ["音乐"] = "100000278/1",
    ["日历"] = "100000277/1",
    ["电视"] = "100000276/1",
    ["影视"] = "100000275/1",
    ["天气"] = "100000063/1",
    --["地图"] = "100000003"
}
local skill_cfg = {}

local function read_skill_cfg(skill)
    local filename
    filename = skill_path.."/"..skill_id_table[skill].."/"..skill_cfg_name
    local input = io.open(filename, "r")
    if nil == input then
        print("open file ",filename," fail")
        return
    end
    
    local str = input:read("*a")
    skill_cfg = json.decode(str)    
end    

local function task_classify( skill, input )
    local cfg_tbl_domain = { 
        [1] = { --客户定制skill的cfg
            fn_cfg   = "nlucfg.lua",
            pwd      = skill_path.."/"..skill_id_table[skill].."/".."tasks",
            vocabs_path = {[1] = skill_path.."/"..skill_id_table[skill].."/".."vocabs",}
            }
        --[2] = { --内建skill的cfg
        --fn_cfg   = "nlucfg.lua",
        --pwd      = "./skill/semlua_buildin/sk0001/tasks/",
        --vocabs_path = {"./skill/semlua_buildin/sk0001/vocabs/"}
        --}
        }

    -- 运行测试
    nluflow:new(cfg_tbl_domain)

    local data = {}
    data.session = {    
        lbs_city = "suzhou"
        }
    data.skillid = "sk0001"
    data.input = {
        func = "query domain",
        reftext = input
        }
    
    local ret
    ret = nluflow:feed(data)
    return ret
end

local function get_task_path( task )
    local task_id
    for k,v in pairs(skill_cfg.tasks) do
        if v.name == task then
            task_id = v.id
            break
        end
    end
    
    local ret = skill_path.."/"..skill_id_table[skill].."/"..task_id
    
    return ret
end

local function task_query( task, input )
    local task_path = get_task_path(task)
    local cfg_tbl_slot = { 
        [1] = { --客户定制skill的cfg
            fn_cfg   = "nlucfg.lua",
            pwd      = task_path,
            vocabs_path = {[1] = skill_path.."/"..skill_id_table[skill].."/".."vocabs"}
            }
        --[2] = { --内建skill的cfg
        --fn_cfg   = "nlucfg.lua",
        --pwd      = "./skill/semlua_buildin/sk0001/tk0001/",
        --vocabs_path = {"./skill/semlua_buildin/sk0001/vocabs/"}
        --}
        }

    nluflow:new(cfg_tbl_slot)
    nluflow:test_mode("skill")
    local data = {}
    data.session = {
        lbs_city = "suzhou",
        }
    data.skillid = "sk0001"
    data.input = {
        reftext = input
        }
        
    local ret = nluflow:feed(data)
    return ret
end

function skill_test( skill, input )
    local ret,str
    local task
    ret = task_classify(skill,input)
    if ret.request.task then
        ret = task_query(ret.request.task,input)
    end
        
    str = json.encode(ret); 
    print(str)        
    return str
end

local skill = "天气"
local input = "今天天气适不适合钓鱼"
skill_test(skill,input)
