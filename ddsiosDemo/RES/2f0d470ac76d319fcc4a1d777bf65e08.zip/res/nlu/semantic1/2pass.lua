local M = {}

M.nlu = {}
local nlu
local json = require 'utils.json'
local _2passcfg -- = require '2passcfg5'
 
 
local function sort_by_slot_start( data1, data2 )
    local s1, s2       
    s1 = data1.data.__SLOT_START__
    s2 = data2.data.__SLOT_START__
    if s1==s2 then
        if data1.data.__SLOT_END__ == data2.data.__SLOT_END__ then
            if data1.data.__SEQ__ ==  data2.data.__SEQ__ then
                return data1.data.__SORT__ < data2.data.__SORT__
            else                         
                return data1.data.__SEQ__ < data2.data.__SEQ__
            end
        else            
            return data1.data.__SLOT_END__ > data2.data.__SLOT_END__
        end
    else        
        return s1 < s2
    end
end

local function sort_by_sort( data1, data2 )
    local s1, s2
    s1 = data1.data.__SORT__
    s2 = data2.data.__SORT__
    return s1 < s2
end

--[[
local main2subdomain = {}
main2subdomain["地图"]={ ROAD=ROAD_in_2pass , POI=POI_in_2pass  }

function M:wtk_sem_2pass_get_subdomain(maindomain, slot)
	local subdomain = {}
	if not maindomain or not slot or maindomain == "" or slot == "" then
		return nil
	end
	for k,v in pairs(main2subdomain) do
		if k == maindomain then
			for k1,v1 in pairs(v) do
				for k2,v2 in pairs(v1) do
					if v2 == slot then
						table.insert(subdomain,k1)
					end
				end
			end
		end
	end
	if table.maxn(subdomain) == 0  then
		return nil
	end
	return subdomain
end
--]]

function M:wtk_sem_get_use_2pass_sem(sem)
	return sem.use_2pass
end

local function wtk_slots_update_by_case( sem, tokens )
    local act = {}
    local slots = {}
    local statistics_slots = {}    
    local tmp_sem    
    local slot_cnt = 0
    local stat_cnt = 0
    
    local debug_str = nil
    if table.maxn(tokens)>0 then
        -- table.sort(tokens,function(a,b) return a.__WEIGHT__ > b.__WEIGHT__ end)
    end
    
    for i,token in pairs(tokens) do
        
        if token.__NAME__ == "crf" or token.__NAME__ == "lmlex" then            
            debug_str = "Rule: <"..token.__NAME__.."> :[__RE_START__="..tostring(token.__RE_START__)..",__RE_END__="..tostring(token.__RE_END__).."]"            
        else            
            debug_str = "Rule: <"..token.__NAME__.."> :[__RE_START__="..tostring(token.__RE_START__)..",__RE_END__="..tostring(token.__RE_END__).."]"
        end
        
        for k,v in pairs(token) do
            if k ~= "__WEIGHT__" and k ~= "__RE_START__" and k~= "__RE_END__" and k~= "__KEY__" and k~="__NAME__" and k~="__SEQ__" and k~= "__ID__" then
                for s in string.gmatch(k,"[^:]+") do
                    local tmp = {}
                
                    tmp.__WEIGHT__   = token.__WEIGHT__
                    tmp.__RE_START__ = token.__RE_START__
                    tmp.__RE_END__   = token.__RE_END__                
                    tmp.__NAME__     = token.__NAME__
                    if token.__SEQ__ then
                        tmp.__SEQ__      = token.__SEQ__
                    else
                        tmp.__SEQ__ = 0
                    end

                    tmp.__KEY__ = s
                    if type(v)=="string" then
                        tmp[s]={[1]=v,[2]=-1,[3]=-1}
                        tmp.__SLOT_START__ = -1
                        tmp.__SLOT_END__   = -1
                    else
                        tmp[s] = v
                        tmp.__SLOT_START__ = v[2]
                        tmp.__SLOT_END__   = v[3]
                    end
                    
                    debug_str = debug_str.."\n    "..s..":[__VALUE__="..tmp[s][1]..",__SLOT_START__="..tostring(tmp[s][2])..",__SLOT_END__="..tostring(tmp[s][3])..",__WEIGHT__="..tostring(token.__WEIGHT__).."]"
                
                    if token.__NAME__ == "crf" or token.__NAME__ == "lmlex" then
                        debug_str = debug_str.."\n--=--=--=--=--=--=--=--=--=--=--=--=--=--=--=--=--=--=--=--=--=--=--=--=--=--=--=--=--=--=--=--"
                        tmp.__SORT__ = stat_cnt                    
                        table.insert(statistics_slots,tmp)
                        stat_cnt = stat_cnt + 1
                    else               
                        if tmp[tmp.__KEY__][1] ~= "__NIL__" then
                            tmp.__SORT__ = slot_cnt              
                            table.insert(slots,tmp)
                            slot_cnt = slot_cnt + 1
                        end
                    end
                end
            end
        end
        
        --debug_str = debug_str.."__RE_START__="..tostring(token.__RE_START__)..",__RE_END__="..tostring(token.__RE_END__)
        nlu:trace(debug_str)
        
    end
    
    if not debug_str then
        nlu:trace("null")    
    end
    
    nlu:lex_slots_to_act(slots,sem, act)
    nlu:statistics_slots_to_act(statistics_slots, sem, act)
    
    local cnt = 0
    if table.maxn(act) > 0 then
        local tmp
        for k,v in pairs(act) do
            if v.data.__VALUE__ == "" then
                act[k] = nil
            else
                if not tmp then
                    tmp = {}
                end
                v.data.__SORT__ = cnt
                table.insert(tmp,v)
                cnt = cnt + 1
            end            
        end
        act = tmp
    end

    if not act then
        act = {}
    end

    if nlu.processor_cb then
       if table.maxn(act) > 1 then
           table.sort(act,sort_by_slot_start)
       end           
       --tmp_sem, act = nlucore.processor_cb:reform_cb_entry(sem,act)
    end
    
    if not act or sem.domain == "@" then         
        return nil,nil
    end
            
    return sem,act
end

local function wtk_slots_update_process(output)
    local sem = {}
    local act = {}
    local tmpsem = {}               
    sem.domain       = nlu.domain    
    sem.input        = nlu.processor.input
    sem.domain_nbest = nlu.nbest
    sem.use_2pass    = nlu.session.use_2pass
    sem.dlg_domain   = nlu.session.dlg_domain
    sem.jump_domain  = nlu.jump_domain
    
    if not output.tokens then
        return sem,nil
    end
   
    tmpsem,act = wtk_slots_update_by_case(sem,output.tokens)      

    return tmpsem,act
end

function M:wtk_load_2passconfig(path)
    _2passcfg = __require__("2passcfg.lua")
    for k,v in pairs(_2passcfg.lex) do
        for kk,vv in pairs(v) do
            if kk ~= nil and vv ~= nil then
                local tmp = {}
                tmp.name = kk
                tmp.fn = vv.fn
                nlu.data.fields.set[kk] = tmp
            end
        end
    end
    for k,v in pairs(_2passcfg.crf) do
        for kk,vv in pairs(v) do
            if kk ~= nil and vv ~= nil then
                nlu.db.crf[kk] = vv
                if vv.lex_fn and vv.lex_fn.name and vv.lex_fn.fn then
                    local tmp = {}
                    tmp.name = vv.lex_fn.name
                    tmp.fn = vv.lex_fn.fn
                    nlu.data.fields.set[vv.lex_fn.name] = tmp
                end
            end
        end
    end
end

local function remove_crf_slots(input)
    local wresult = {}
    local lresult = {}
    local result = {}
    local weight,length
    for k,v in pairs(input) do
        if k == 1 then
            table.insert(wresult,input[k])
            weight = v.data.__WEIGHT__
        else
            if v.data.__WEIGHT__ > weight then
                wresult = {}
                table.insert(wresult,input[k])
                weight = v.data.__WEIGHT__
            elseif v.data.__WEIGHT__ == weight then
                table.insert(wresult,input[k])
            end
        end
    end

    for k,v in pairs(wresult) do
        if k == 1 then
            table.insert(lresult,wresult[k])
            length = v.data.__SLOT_END__ - v.data.__SLOT_START__
        else
            if v.data.__SLOT_END__ - v.data.__SLOT_START__ > length then
                lresult = {}
                table.insert(lresult,wresult[k])
                length = v.data.__SLOT_END__ - v.data.__SLOT_START__
            elseif v.data.__SLOT_END__ - v.data.__SLOT_START__ == length then
                table.insert(lresult,wresult[k])
            end
        end
    end

    table.sort(lresult,sort_by_sort)
    if table.getn(lresult) > 0 then
        table.insert(result,lresult[1])
    end
    return result
end

function M:wtk_sem_2pass_process(sem, value, sub_domain)
    nlu = self.nlu
    self:wtk_load_2passconfig(nlu.sys.pwd)

    local result = {}
    local nbest
    local data = {}
    local sem = {}
    local act = {}
    data.reftext = value
    local flag = false

    if data.reftext then
        if sub_domain == "ROAD" then
            result,nbest = nlu:second_pass_process_query_lex(sub_domain,data);
            if nlu.debug then
                print("Post.......................................")
                nlu:print_data(result)
            end
        --[[if result and nlu.use_lmlex then              
            nlu:process_query_lmlex(nlu.domain,result)
            if nlu.debug then
                print("lmlex..........................................")
                nlu:print_data(result)
            end                
        end
        --]]
        elseif sub_domain == "POI" then
            local tmp = {}
            result.tokens = {}
            result.nTokens = 0
            if result and nlu.use_crf then
                if nlu.debug then
                    print("crf..........................................")
                end
                tmp = nlu:second_pass_process_query_lex("poi_domain",data)
                if tmp.tokens and tmp.tokens[1] and tmp.tokens[1].domain == "POI过滤" then
                    nlu:second_pass_process_query_crf(sub_domain,result,value)
                    flag = true
                end
            end
        end

        if nlu.use_wtk_version then
            sem,act = wtk_slots_update_process(result)
            act = remove_crf_slots(act)
            if nlu.debug then
                print("Update.......................................")
                --table.print(sem)
                print("Update nbest.......................................")
                --table.print(act)
            end
        end          
        if flag == false then
            sem.domain = "@"
        end
    end
    return sem,act
end
return M
