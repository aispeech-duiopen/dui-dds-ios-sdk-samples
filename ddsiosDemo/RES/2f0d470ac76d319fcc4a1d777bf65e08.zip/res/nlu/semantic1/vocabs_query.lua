local M = {}

local nlucore = require 'nlucore'
local kvreader = require 'kvreader'
M.regex_cfg = {}

function M:regex_query_config(domain, fn,pwd,path)
    self.regex_cfg.domain = domain
    self.regex_cfg.fn = fn
    self.regex_cfg.pwd = pwd
    self.regex_cfg.path = path
end

function M:reform_regex_result(result)
    local ret = {}
    ret.vocabs = {}
    
    if table.maxn(result.tokens) > 0 then
        for k, v in pairs(result.tokens) do
            for k1, v1 in pairs(v) do
                local tmp = {}
                local key = k1
                if string.find(k1,"+") then
                    key = (string.gsub(k1,"+","."))                            
                end
                if k1 ~= "__WEIGHT__" and type(v1) == "table" then
                    tmp[key] = {}
                    if v1[2] ~= -1 or v1[3] ~= -1 then
                        table.insert(tmp[key],v1[2])
                        table.insert(tmp[key],v1[3])
                        table.insert(ret.vocabs,tmp)
                    end                    
                end
            end
        end
    end
    return ret
end

function M:regex_query( str )    
    
    local nlu = nlucore.new(self.regex_cfg.fn, self.regex_cfg.pwd, self.regex_cfg.path )
        
    nlu.opts.use_reform = false
    
    local data = {}
    data.session = {
         domain = self.regex_cfg.domain
    }
    data.skillid = "sk0001"
    data.input = {
         reftext = str
    }    
    local ret = nlu:feed(data)
    ret = self:reform_regex_result(ret)    
    --table.print(ret)
    nlu:reset()    
    nlu = nil
    return ret 
end

function M:append_result( result, output )
    if result and result.vocabs then
        if table.maxn(result.vocabs) >  0 then
            for k, v in pairs(result.vocabs) do
                table.insert(output.vocabs,v)
            end
        end
    end 
    return output
end

function M:vocabs_query(vocabs_table,str)
    local ret = {}
    local result    
    
    ret.vocabs = {}
    for k, v in pairs(vocabs_table) do
        if type(v) == "string" then
            local reader = kvreader.new(v,k)
            reader:query(str)
            result = reader:get_query_result()
            self:append_result( result, ret )
            reader:delete()
            reader = nil;
        elseif type(v) == "table" then
            for k1, v1 in pairs(v) do
                local reader = kvreader.new(v1,k)
                reader:query(str)
                result = reader:get_query_result()
                self:append_result( result, ret )
                reader:delete()
                reader = nil;
            end
        end
    end
    
    if self.regex_cfg.domain then
        result = self:regex_query(str)
        --table.print(result)
        self:append_result(result,ret)
    end
    
    self.regex_cfg = {}
    
    return ret
end

return M
