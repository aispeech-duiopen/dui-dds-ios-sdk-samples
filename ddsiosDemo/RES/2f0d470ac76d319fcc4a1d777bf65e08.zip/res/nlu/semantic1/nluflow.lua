local M = {}

M.cfg_tbl = {}
M.test = nil
--cfg_tbl = {
-- cfg在表内的顺序代表优先级,[2]优先级最高
--  [1] =  { --客户定制skill的cfg
--      fn_cfg   = "nlucfg.lua",
--      pwd      = "/home/aisp/workspace/luanew/src/res"，
--      ext_path = {"/home/aisp/workspace/luanew/src/res","/home/aisp/workspace/luanew/src/vocab"}，
--  },
--  [2] = {  --内建skill的cfg
--      fn_cfg   = "nlucfg1.lua",
--      pwd      = "/home/aisp/workspace/luanew/src/res"，
--      ext_path = {"/home/aisp/workspace/luanew/src/res","/home/aisp/workspace/luanew/src/vocab"}
--  }
--}
function M:new(cfg_tbl)        
    self.cfg_tbl = cfg_tbl   
end

function M:test_mode(str)
    self.test = str
end

--data.flows = ["lex","crf","lm","kv"] (default:"lex") flow是一个数组,内容的顺序是调用相应engine处理的顺序
--data.session.domain
--data.session.dgl_domain   = "@";
--data.session.used_domain_set.num = 0;
--data.session.used_domain_set.set = {};
--data.session.lbs_city. = "";
--data.skillid               "sk00001" 服务端使用feed功能必须提供skillid参数        
--data.input.func            "query domain" or "query LM"(default:"query LM")
--data.input.reftext ==> input string
--data.input.pingyin
--data.wakeup.common.word
--data.wakeup.common.pingyin
--data.wakeup.custom.word
--data.wakeup.custom.pingyin
--data.opts.use_slot_index   "on" or "off"(default:"off")
--data.opts.use_stop_word    "on" or "off"(default:"on")
--data.opts.use_force_domain "on" or "off"(default:"on") 
--data.opts.use_reform       "on" or "off"(default:"on")
--data.opts.use_merge        "on" or "off"(default:"on")
function M:feed(data)
    local nlucore = require 'nlucore'
    local nlu
    local first_ret
    local second_ret
    local ret
    
    if self.cfg_tbl and type(self.cfg_tbl) == "table" then
        for i=1, table.maxn(self.cfg_tbl) do
            local empty_result = true           
            if self.cfg_tbl[i] then
                
                nlu = nlucore.new( self.cfg_tbl[i].fn_cfg, self.cfg_tbl[i].pwd, self.cfg_tbl[i].vocabs_path )
                if self.test then
                    nlu:set_test_mode(self.test)
                else
                    nlu.use_wtk_version = false
                end
                ret = nlu:feed(data)
                if not first_ret then
                    first_ret = ret
                else
                    second_ret = ret
                end
                if data.input.func and data.input.func == "query domain" then
                    --if ret.semantics.request.task ~= "@" then
                    --    second_ret = ret
                    --end 
                else
                    if not ret.semantics then
                        empty_result = false
                    else
                        if ret.semantics.request.slotcount > 0 then
                            empty_result = false
                        end
                    end
                end
            end
            nlu:reset()
            --nlu:print_data(ret)
            --nlu = nil
            if not empty_result then
                break
            end            
        end                  
    end
    
    if second_ret then
        if data.input.func and data.input.func == "query domain" then             
            if first_ret.semantics == nil then
                if second_ret.semantics == nil then
                    ret = first_ret
                else
                    ret = second_ret
                end
            else
                if second_ret.semantics == nil then
                    ret = first_ret
                else                
                    if first_ret.semantics.request.task == second_ret.semantics.request.task then
                        ret = first_ret
                    else
                        ret = first_ret
                        if second_ret.semantics.nbest then
                            second_ret.semantics.nbest = nil
                        end
                        local domain_exist = false
                        if ret.semantics.nbest == nil then
                            ret.semantics.nbest = {}
                        else
                            for k,v in pairs(ret.semantics.nbest) do
                                if v.request.task == second_ret.semantics.request.task then
                                    domain_exist = true
                                end 
                            end
                        end
                        if not domain_exist then
                            table.insert(ret.semantics.nbest,second_ret.semantics)
                        end                    
                    end
                end
            end
        else
            if ret.semantics.request.slotcount == 0 then
                ret = first_ret
            end
        end
    else
        ret = first_ret
    end
    if nlu then
        nlu:print_data(ret)
    end
    return ret
end

return M
