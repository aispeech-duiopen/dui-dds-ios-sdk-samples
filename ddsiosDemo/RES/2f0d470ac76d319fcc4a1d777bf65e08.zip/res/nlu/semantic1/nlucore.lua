local def = require("utils.base")
local json = require("utils.json")
local M = def:class()
local second_pass= require("2pass")
local debug_str

local _engines = {        
        core   = require("engine.core"),
        crf    = require("engine.crf"), --
        lex    = require("engine.lex"), --
        lmlex  = require("engine.lmlex"), --
        linear = require("engine.linear"),
        pinyin = require("engine.pinyin"), --        
    }

local _modules = {
        pre    = require("semantic.pre"),
        post   = require("semantic.post"),
        reform = require("semantic.reform"), 
    }

local cache_engine = {}

local _file,_pwd
local _cfg = {}
local function load_config(file ,pwd)
    collectgarbage("collect")
    if _file == file and _pwd == pwd then
        return _cfg
    end

--    print("load config")
    _file = file
    _pwd  = pwd
    -- for local luabin test --    
    def:set_pwd(pwd)
    --_cfg._cfg = dofile(pwd.."/"..file)
    _cfg._cfg = __require__(file)

    --_cfg._db  = dofile(string.gsub(_cfg._cfg.db.lex.fn,"${pwd}",pwd))
    _cfg._db  = __require__(string.gsub(_cfg._cfg.db.lex.fn,"${pwd}",""))

    if _cfg._cfg.db.crf and _cfg._cfg.db.crf.fn then
        --_cfg._crf = dofile(string.gsub(_cfg._cfg.db.crf.fn,"${pwd}",pwd))
        _cfg._crf = __require__(string.gsub(_cfg._cfg.db.crf.fn,"${pwd}",""))
    end

    --_cfg._post = dofile(string.gsub(_cfg._cfg.processor.post.cfg.post_func,"${pwd}",pwd))
    _cfg._post = __require__(string.gsub(_cfg._cfg.processor.post.cfg.post_func,"${pwd}",""))
    --_cfg._processor_cb = dofile(string.gsub(_cfg._cfg.processor.post.cfg.reform_func,"${pwd}",pwd))
    _cfg._processor_cb = __require__(string.gsub(_cfg._cfg.processor.post.cfg.reform_func,"${pwd}",""))
    if _cfg._cfg.processor.post.cfg.reform_ves then
        --_cfg._reform_ves = dofile(string.gsub(_cfg._cfg.processor.post.cfg.reform_ves,"${pwd}",pwd))
        _cfg._reform_ves = __require__(string.gsub(_cfg._cfg.processor.post.cfg.reform_ves,"${pwd}",""))        
    end

    if _cfg._processor_cb.PINYIN_SOUNDEX_SLOT then
        _modules.reform:set_pinyin_soundex_slot(_cfg._processor_cb.PINYIN_SOUNDEX_SLOT)
    end

--[[
    if _cfg._processor_cb.RULE_TO_SPECICAL_MERGE then
       _modules.post:set_sp_rule(_cfg._processor_cb.RULE_TO_SPECICAL_MERGE)
    end
--]]    
    cache_engine = nil
    cache_engine = {}
end

function M:__init__(file, pwd, vocabs_path)
--    print("nlucore init")
    
    --self.debug = true
    self.debug = false
    self.use_trace = false
    --self.use_wtk_version = false
    self.use_wtk_version = true
    self.output_wtk_format = false --for test tools
            
    self.flows = {
       "lex",
       "crf",
       "lm"      
    }
      
    self.opts = {
        use_slot_index       = true, -- 
        use_stop_word        = true, --not implemented
        use_force_domain     = true,  
        use_reform           = true,
        use_merge            = true,
        use_session_domain   = true        
    }
    
    self.session = {  
        domain          = "@",  --"@" means no domain
        dlg_domain      = "@",
        used_domain_set = { 
            num = 0,
            set = {}
        },
        lbs_city = "",
        use_2pass = false,
    }
    
    self.sys = {
        name = "",
        res  = "",
        pwd  = "."
    }

    self.processor ={
        pre  = { 
            filter = {} 
            },
        post   = {},
        input  = "",
        pinyin = ""
    }

    self.db = {
        lex   = {},
        lmlex = {}
    }
    
    self.engine = {
        running = "",
        lex = {
            use_trie = 0,
            bin_fn = "",
            kv_set = {}
        }
    }

    self.data = {
        force_domain      = "@",
        default_domain    = "@", -- define defautl domain
        fields            = {  -- fields defined in config file
            num           = 0,
            set           = {},
        }
    }

    self.domain            = "@" -- domain is using.
    self.jump_domain       = "@"
    self.source            = "@"
    self.weight            = 0.0
    self.nbest = {}
    self.domain_act = nil
    self.skillid = ""
    self.input = ""
    self.request_version = ""
    self.use_index = true
    self.output_format = nil
    self.confidence = nil
    
    self.key ={
        no_domain   = "@",
        jump_domain = "jump_domain",
        domain      = "domain"
    }

    self.engines = _engines
    self.modules = _modules
    self.second_pass = second_pass
    self.second_pass.nlu = self
    load_config(file ,pwd)
--[[    
    self.engines = {   
        core   = require("engine.core"),
        crf    = require("engine.crf"), --
        lex    = require("engine.lex"), --
        lmlex  = require("engine.lmlex"), --
        linear = require("engine.linear"),
        pinyin = require("engine.pinyin"), --        
    }
    self.modules = {
        pre    = require("semantic.pre"),
        post   = require("semantic.post"),
        reform = require("semantic.reform"), 
    }
--]]
--[[    
    local cfg = dofile(pwd.."/"..file)
    self.sys       = cfg.sys
    self.sys.pwd   = pwd
    self.processor = cfg.processor
    self.data      = cfg.domain
    
    if cfg.use_lmlex and cfg.use_lmlex == 1 then
        self.use_lmlex = true
    else
        self.use_lmlex = false
    end
    
    if cfg.use_crf and cfg.use_crf == 1 then
        self.use_crf = true
    else
        self.use_crf = false
    end
    
    if cfg.use_linear and cfg.use_linear == 1 then
        self.use_linear = true
    else
        self.use_linear = false
    end
        
    if cfg.sys and cfg.sys.use_slot_index then
        if cfg.sys.use_slot_index == 0 then
            self.opts.use_slot_index = false
        else
            self.opts.use_slot_index = true
        end
    end
    if cfg.domain and cfg.domain.use_force_domain then
        if cfg.domain.use_force_domain == 0 then
            self.opts.use_force_domain = false
        else
            self.opts.use_force_domain = true
        end
    end
    
    if cfg.use_stop_word and cfg.use_stop_word == 1 then
        self.opts.use_stop_word = true
    else
        self.opts.use_stop_word = false
    end
        
    self.cfg = {}
    self.cfg.opts = self.opts    
    
    local db = dofile(string.gsub(cfg.db.lex.fn,"${pwd}",pwd))
    self.db.lex = db    
    if cfg.db.lmlex and cfg.db.lmlex.fn then
        self.db.lmlex = dofile(string.gsub(cfg.db.lmlex.fn,"${pwd}",pwd))
    end
    if cfg.db.crf and cfg.db.crf.fn then
        self.db.crf = dofile(string.gsub(cfg.db.crf.fn,"${pwd}",pwd))
    end
    if cfg.db.linear and cfg.db.linear.fn then
        self.db.linear = dofile(string.gsub(cfg.db.linear.fn,"${pwd}",pwd))
    end
    local post = dofile(string.gsub(cfg.processor.post.cfg.post_func,"${pwd}",pwd))
    self.modules["reform"].pinyin.cfg = cfg.pinyin.cfg
    self.processor_cb = dofile(string.gsub(cfg.processor.post.cfg.reform_func,"${pwd}",pwd))
    
    cfg = nil
    db = nil
--]]

    local cfg = _cfg._cfg
    self.sys       = cfg.sys
    self.sys.pwd   = pwd
    self.processor = cfg.processor
    self.processor.input  = ""
    self.processor.pinyin = ""
    self.data      = cfg.domain
    
    if cfg.use_lmlex and cfg.use_lmlex == 1 then
        self.use_lmlex = true
    else
        self.use_lmlex = false
    end
    
    if cfg.use_crf and cfg.use_crf == 1 then
        self.use_crf = true
    else
        self.use_crf = false
    end
    
    if cfg.use_linear and cfg.use_linear == 1 then
        self.use_linear = true
    else
        self.use_linear = false
    end
        
    if cfg.sys and cfg.sys.use_slot_index then
        if cfg.sys.use_slot_index == 0 then
            self.use_index = false
        else
            self.use_index = true
        end
    end
    if cfg.domain and cfg.domain.use_force_domain then
        if cfg.domain.use_force_domain == 0 then
            self.opts.use_force_domain = false
        else
            self.opts.use_force_domain = true
        end
    end
    
    if cfg.use_stop_word and cfg.use_stop_word == 1 then
        self.opts.use_stop_word = true
    else
        self.opts.use_stop_word = false
    end
        
    self.cfg = {}
    self.cfg.opts = self.opts
    self.cfg.use_index = self.use_index    
    
    local db = _cfg._db
    self.db.lex = db    
    if cfg.db.lmlex and cfg.db.lmlex.fn then
        self.db.lmlex = _cfg._lmlex
    end
    if cfg.output_format then
        self.output_format = cfg.output_format
    end
    if cfg.db.crf and cfg.db.crf.fn then
        self.db.crf = _cfg._crf
    end
    if cfg.db.linear and cfg.db.linear.fn then
        self.db.linear = _cfg._linear
    end
    local post = _cfg._post
    self.modules["reform"].pinyin.cfg = cfg.pinyin.cfg
    self.processor_cb = _cfg._processor_cb
    if _cfg._reform_ves then
        self.reform_ves = _cfg._reform_ves
    end
    
    cfg = nil
    db = nil
   
    self.modules["pre"].opts = self.opts
    self.modules["post"].opts = self.opts
    self.modules["post"]:init(post)
    self.modules["reform"].opts = self.opts
    self.modules["reform"].pinyin.pwd = pwd
    
    if vocabs_path then
        if type(vocabs_path) == "table" or type(vocabs_path) == "string" then
            self.db["lex"].vocabs_path = vocabs_path
        end
    end

--[[
    if self.db["lex"].vocabs_path then
        if type(self.db["lex"].vocabs_path) == "string" then
            self.db["lex"].vocabs_path = string.gsub(self.db["lex"].vocabs_path,"${pwd}",pwd)
        else
            if type(self.db["lex"].vocabs_path) == "table" then
                for k,v in pairs(self.db["lex"].vocabs_path) do
                    self.db["lex"].vocabs_path[k]=string.gsub(self.db["lex"].vocabs_path[k],"${pwd}",pwd)
                end
            end
        end        
    else
        self.db["lex"].vocabs_path = pwd
    end
--]]
    --M:load_config(file,pwd)    
end

function M:preload_lex_resources()
     if self.data and self.data.fields and self.data.fields.set then       
          for k,v in pairs(self.data.fields.set) do
              --print(k,v.fn)
              local engine_cfg = {} 
              engine_cfg.use_trie,engine_cfg.kv_set = self:get_db_data( "lex" );
              engine_cfg.use_mmap = self.db.lex.use_mmap
              engine_cfg.bin_fn = v.fn;
              self:preload_engine_cached( k, "lex", engine_cfg )
          end
          
          if self.db and self.db.lmlex then
              for k1, v1 in pairs(self.db.lmlex) do
                  if type(v1)=="table" then
                      local engine_cfg = {} 
                      engine_cfg.use_trie,engine_cfg.kv_set = self:get_db_data( "lex" );
                      engine_cfg.use_mmap = self.db.lex.use_mmap
                      engine_cfg.bin_fn = v1.lex.fn;
                      self:preload_engine_cached( "lmlex"..k1, "lex", engine_cfg )
                  end
              end
          end
     end
end
--************************************************************************--
--                       config setting functions                         --
--************************************************************************--
--[[
function M:load_config(file ,pwd)
    
    local cfg = require(file)
    self.sys= cfg.sys
    self.sys.pwd = pwd
    self.processor= cfg.processor
    self.data = cfg.domain
    local db = require(cfg.db.lex.fn)
    self.db.lex = db
end
--]]

function M:get_sys_name()
    return self.sys.name
end

function M:get_sys_res()
    return self.sys.res
end

function M:get_sys_pwd()
    return self.sys.pwd
end


function M:set_processor( data )
    self.processor = data;
end

function M:set_test_mode( str )
    if str == "skill" or str == "SKILL" then
        self.output_wtk_format = true
        self.modules["post"].wtk_format = true
        self.use_wtk_version = false
    end
    if str == "wtk" or str == "WTK" then
        self.output_wtk_format = false
        self.use_wtk_version = true
    end
end
--************************************************************************--
--                        engine db setting functions                     --
--************************************************************************--
function M:get_file_name(str)
    local ret
    ret  =  string.match(str, ".+/([^/]*%.%w+)$")
    if not ret then
        ret = str
    end
    return ret        
end

function M:is_file_exist(fn)
    local file = io.open(fn, "rb")
    local ret = false
    if file then 
        io.close(file)
        ret = true 
    end
    return ret
end

function M:get_db(name)
    return self.db[name]
end

-- 所有使用到的kv文件需要在lexcfg.lua中有定义
-- 如果vocabs_path中有同名文件,则nlu会同时匹配这些文件，如同名文件中有相同的词条,则nlu的输出受lex规则与merage规则的影响,会有不确定性.
function M:get_db_data(name)
    local kvset = {}
    --kvset = self.db[name].data
    if name == "lex" then 
        local key
        for k,v in pairs(self.db[name].data) do
            --local fn = string.gsub(v,"${pwd}",self.sys.pwd)
            -- step 1 更改lexcfg配置文件的路径
            local file_name = self:get_file_name(v)
            local prefix = "="
            key = k            
            -- step 2 --        
            --查找文件在目录中是否实际存在，如不存在,则在ext_path中查找，如找到就更改kv中对应的value,否则删除该文件--
            --用户文件的导入用这个方式--            
            if type(self.db[name].vocabs_path) == "string" then
                local fname
                fname = self.db[name].vocabs_path.."/"..file_name            
                if self:is_file_exist(fname) then
                    kvset[key] = fname                   
                else
                    print("can find db:",file_name)
                    kvset[key] = nil 
                end
            else
                local is_find = false
                for pk,pv in pairs(self.db[name].vocabs_path) do
                    local fname =  pv.."/"..file_name
                    if self:is_file_exist(fname) then
                        kvset[key] = fname
                        key = prefix..key
                        is_find = true                        
                    end                                        
                end
                if not is_find then
                    print("can find db:",file_name)
                    kvset[k] = nil
                end
            end
        end
    end
        
    local is_empty = true
    for k,v in pairs(kvset) do
        is_empty = false
        break
    end
    
    if is_empty then
        kvset = nil;
    end
                                     
    return self.db[name].use_trie,kvset
end

function M:get_db_version(name)
    return self.db[name].version
end

--************************************************************************--
--                           engine functions                             --
--************************************************************************--
function M:run_engine( name, cfg, input )        
    local egn, output
    local group = self.domain
    
    egn = self.engines[name].new(cfg,self.sys.pwd, group)
    egn:feed(input,self.skillid)    
    output = egn:get_result();
        
    if self.debug then        
        self:print_data(output)
    end
    if name == "lex" or name == "crf" or name == "lmlex" or name == "vocabs" or name == "linear" then    
        egn:delete()
    else
        egn:reset()
    end
    egn = nil            
    return output
end

function M:preload_engine_cached( domain, name, cfg )
    local output
    local group = domain
    
    if not cache_engine[name] then
        cache_engine[name] = {}
    end
    
    if self.use_wtk_version and name == "lex" then
        cfg.use_kv_copy = 1
    end
    
    if not cache_engine[name][domain] then
        --print("new engine cached",name,domain)            
        cache_engine[name][domain] = self.engines[name].new(cfg, self.sys.pwd, group)    
    end
end

function M:run_engine_cached( domain, name, cfg, input )        
    local output
    local group = self.domain
    
    if not cache_engine[name] then
        cache_engine[name] = {}
    end
    
    if self.use_wtk_version and name == "lex" then
        cfg.use_kv_copy = 1
    end
    
    if not cache_engine[name][domain] then
        --print("new engine cached",name,domain)            
        cache_engine[name][domain] = self.engines[name].new(cfg,self.sys.pwd, group)    
    end
    --print("input",input,name,domain)
    cache_engine[name][domain]:feed(input,self.skillid)    
    output = cache_engine[name][domain]:get_result();
        
    if self.debug then        
        self:print_data(output)
    end
    cache_engine[name][domain]:reset()                
    return output
end

--************************************************************************--
--                         processor functions                            --
--************************************************************************--  
function M:process_in_domain( domain, input )    
        
    local field, result
    local engine = {}
    local len

    --self.domain = domain --记录task
    if not self:field_is_existed(domain) then
        print("~~error~~: can\'t find the field(defined in nlucfg.lua) of",domain)
        return result
    end
    
    field  = self:get_field ( domain );
    engine.use_trie,engine.kv_set = self:get_db_data( "lex" );
    engine.use_mmap = self.db.lex.use_mmap
    engine.bin_fn = field.fn;

    self.modules["pre"]:set_fileter(self.processor.pre.filter)
    
    if not self.processor.input or self.processor.input == "" then
        local input_str
        input_str,self.input = self.modules["pre"]:pre_processor(input)       
        if input_str and string.len(input_str) > 0 then
            self.processor.input = input_str
        else
            self.processor.input = "@"
        end   
    end
    
    if self.use_wtk_version then                
        result = self:run_engine_cached(domain,"lex", engine, self.processor.input )
    else
        result = self:run_engine("lex", engine, self.processor.input )
    end
    
    self.source = domain
    --[[
    if self.use_wtk_version and domain == "domain" then        
        result = self:run_engine_cached(domain,"lex", engine, self.processor.input )
    else
        result = self:run_engine("lex", engine, self.processor.input )
    end
    --]]
    if result and result.nTokens > 0 then
       result = self.modules["post"]:post_processor(domain,result);
    else
       result = {}
       result.nTokens = 0
       result.tokens = {}
    end

    return result
end

function M:process_in_2pass_domain( domain, input )

    local field, result
    local engine = {}
    local len

    --self.domain = domain --记录task
    if not self:field_is_existed(domain) then
        print("~~error~~: can\'t find the field(defined in nlucfg.lua) of",domain)
        return result
    end

    field  = self:get_field ( domain );
    engine.use_trie,engine.kv_set = self:get_db_data( "lex" );
    engine.use_mmap = self.db.lex.use_mmap
    engine.bin_fn = field.fn;

    if self.use_wtk_version then
        result = self:run_engine_cached(domain,"lex", engine, input )
    else
        result = self:run_engine("lex", engine, input )
    end
    --[[
    if self.use_wtk_version and domain == "domain" then        
        result = self:run_engine_cached(domain,"lex", engine, self.processor.input )
    else
        result = self:run_engine("lex", engine, self.processor.input )
    end
    --]]
    if result and result.nTokens > 0 then
       result = self.modules["post"]:post_processor(domain,result);
    else
       result = {}
       result.nTokens = 0
       result.tokens = {}
    end

    return result
end

function M:second_pass_process_query_lex(domain,data)
    local input,result,weight
    input = data.reftext
    weight = 1
    
    if domain ~= self.key.no_domain then
        debug_str = "-=- 2pass query lex -=- \ndomain="..domain
        self:trace(debug_str)
        result = self:process_in_2pass_domain( domain, input )
    end

    if not result then
        result = {}
        result.nTokens = 1
        result.tokens = {}
        result.tokens[1] = nil
    end
    return result,nil
end

function M:process_query_lex( domain, data )
    local input,result,weight
    local nbest_result = {};
    input = data.reftext
    if domain == self.key.no_domain or domain == nil then
        domain,weight = self:query_domain( input );
        --print(domain)
    else
        self.domain = domain
        weight = 1
    end

    local nbest_update
    if domain ~= self.key.no_domain and self.use_wtk_version then  
        if self.nbest then
            local sem = {}
            sem.domain       = domain
            sem.weight       = weight
            sem.source       = self.source    
            sem.input        = self.processor.input
            sem.domain_nbest = self.nbest
            sem.use_2pass    = self.session.use_2pass
            sem.dlg_domain   = self.session.dlg_domain
            sem.jump_domain  = self.jump_domain    
            self.domain, self.nbest = self.processor_cb:nbest_domain_cb_entry( sem, self.nbest )
            domain = self.domain
            nbest_update = self.nbest            
        end            
    end            

    if domain ~= self.key.no_domain then
        debug_str = "-=- query lex -=- \ndomain="..domain
        self:trace(debug_str)  
        result = self:process_in_domain( domain, input )
    end

    if not result then
        result = {}
        result.nTokens = 1
        result.tokens = {}
        result.tokens[1] = nil
    end
    
    if nbest_update then        
        for k,v in pairs(nbest_update) do                                      
             local tmp = {}                   
             tmp = self:process_in_domain(nbest_update[k].domain,input)                                                
             table.insert(nbest_result,tmp)
        end    
    else        
        self.nbest = {}
    end
    
    return result, nbest_result;    
end

function M:process_lmlex_query_lex(domain, input)    
        
    local result
    local cfg = {}    

    --self.domain = domain --记录task
    if not self:field_is_existed(domain) then
        return result
    end
    
    cfg.use_trie,cfg.kv_set = self:get_db_data( "lex" );
    cfg.use_mmap = self.db.lex.use_mmap
    cfg.bin_fn = self.db.lmlex[domain].lex.fn;    
    
    result = self:run_engine_cached( "lmlex"..domain,"lex", cfg, input )
   
    --result = self:run_engine("lex", cfg, input );
    
    self.modules["post"]:post_processor("lmlex"..domain,result);

    return result 
end

function M:query_sub_slot(domain, name, value, str )       
    local input
    local output = {}
    local cfg = {}    

    cfg.use_trie,cfg.kv_set = self:get_db_data( "lex" );
    cfg.use_mmap = self.db.lex.use_mmap
    cfg.bin_fn = self.db.lmlex[domain].lex.fn;    
    
    local word_num = value[3]        
    local from = value[2] + 1    
    while from <= word_num 
    do
       local result, offset
       offset = 0
       
       input = _engines["core"]:sub_word_string(str,from,value[3])              
       result = self:run_engine_cached( "lmlex"..domain,"lex", cfg, input )
       if table.maxn(result.tokens) > 0 then               
           self.modules["post"]:post_processor("lmlex"..domain,result);
           --table.print(result)
           for k,v in pairs(result.tokens) do
                if type(v)=="table" and v[name] then                    
                    offset = v[name][2]
                    v[name][2] = from + v[name][2]
                    v[name][3] = from + v[name][3]                    
                    table.insert(output,v[name])
                end
           end                   
       else
           break
       end
       --from = from + offset + 1      
       from = from + 1
    end
    
    local to = value[3]
    from = value[2]
    while from < to 
    do
       local result, offset
       offset = 0
       
       input = _engines["core"]:sub_word_string(str,from,to-1)                  
       result = self:run_engine_cached( "lmlex"..domain,"lex", cfg, input )
       if table.maxn(result.tokens) > 0 then               
           self.modules["post"]:post_processor("lmlex"..domain,result);
           --table.print(result)
           for k,v in pairs(result.tokens) do
                if type(v)=="table" and v[name] then                    
                    offset = v[name][2]
                    v[name][2] = from + v[name][2]
                    v[name][3] = from + v[name][3]                    
                    table.insert(output,v[name])
                end
           end                   
       else
           break
       end
       --to = from + offset      
       to = to - 1
    end
    
    if table.maxn(output) == 0 then
        output = nil    
    end 
    return output 
end

function M:prepare_lmlex_data(domain,input )    
    local ret = {}
    local cnt = 0;
--{"nTokens":4,"tokens":[{"__WEIGHT__":0,"歌手名":["刘德华",3,5],"__RE_START__":3,"__RE_END__":5},{"__WEIGHT__":0,"__RE_END__":8,"__RE_START__":7,"歌曲名":["爱你",7,8]},{"__WEIGHT__":0,"__RE_END__":11,"__RE_START__":7,"歌曲名":["爱你一万年",7,11]},{"__WEIGHT__":0,"__RE_END__":11,"__RE_START__":9,"歌曲名":["一万年",9,11]}]}
    if input.tokens and table.maxn(input.tokens) == 0 then
        return nil
    end
--[[    
    if table.maxn(input.tokens) > 1 then
        table.sort(input.tokens,sort_by_start)
    end
--]]    
    for k,v in pairs(input.tokens) do
        for key,value in pairs(v) do
             if type(value) == "table" then
                 if type(value[1])=="string" and string.len(value[1])>0 then
                     if self.db.lmlex[domain].mapping[key] then                         
                     if type(self.db.lmlex[domain].mapping[key])=="table" then
                         local add_to_table = false
                         for k1,v1 in pairs(self.db.lmlex[domain].mapping[key]) do
                             local tmp = {}
                             local in_table = false                             
                             tmp.word  = v1
                             tmp.value = value[1]
                             tmp.from  = value[2]
                             tmp.to    = value[3]
                             for k2, v2 in pairs(ret) do 
                                 if v2.word == tmp.word and v2.from == tmp.from and v2.to == tmp.to then
                                     in_table = true
                                 end
                             end
                             if not in_table then
                                 table.insert(ret,tmp)                                 
                                 cnt = cnt + 1
                                 add_to_table = true
                             end
                         end
                         
                         if add_to_table then
                             local sub = self:query_sub_slot(domain,key,value,self.processor.input)
                             if sub then                                 
                                 for k3, v3 in pairs(sub) do
                                     for k4,v4 in pairs(self.db.lmlex[domain].mapping[key]) do
                                         local tmp = {}
                                         tmp.word  = v4
                                         tmp.value = v3[1]
                                         tmp.from  = v3[2]
                                         tmp.to    = v3[3]
                                         table.insert(ret,tmp)
                                         cnt = cnt + 1
                                     end
                                 end
                             end
                         end
                     else                         
                         local tmp = {}
                         local in_table = false
                         tmp.word  = self.db.lmlex[domain].mapping[key]
                         tmp.value = value[1]
                         tmp.from  = value[2]
                         tmp.to    = value[3]
                         for k2, v2 in pairs(ret) do 
                              if v2.word == tmp.word and v2.from == tmp.from and v2.to == tmp.to then
                                   in_table = true
                              end
                         end
                         if not in_table then
                             table.insert(ret,tmp)
                             cnt = cnt + 1
                             local sub = self:query_sub_slot(domain,key,value,self.processor.input)
                             if sub then
                                 for k3, v3 in pairs(sub) do
                                     local tmp = {}
                                     tmp.word  = self.db.lmlex[domain].mapping[key]
                                     tmp.value = v3[1]
                                     tmp.from  = v3[2]
                                     tmp.to    = v3[3]
                                     table.insert(ret,tmp)
                                     cnt = cnt + 1
                                 end
                             end  
                         end                         
                     end
                     end
                 end
             end
        end
    end
    
    return ret,cnt          
end                 

function M:merge_with_lex_result(lex_result, engine, result)
--[[
    local is_found
    for i=1, table.maxn(result[engine]) do
        for k,v in pairs(result[engine][i]) do
            is_found = false
            for i1=1, table.maxn(lex_result.tokens) do
                for k1,v1 in pairs(lex_result.tokens[i1]) do
                    if( k1 == k ) then
                        is_found = true
                        if type(v[1])=="string" and type(v1[1])=="string" then
                            if string.len(v[1]) > string.len(v1[1]) then
                                lex_result.tokens[i1][k1] = v
                            else
                                if string.len(v[1]) == string.len(v1[1]) then
                                    if v1[1] < v[1] then                                    
                                        lex_result.tokens[i1][k1] = v
                                    end
                                end
                            end
                        end
                    end
                end
            end
            if not is_found then
                local tmp = {}
                tmp[k] = v
                table.insert(lex_result.tokens,tmp)
            end
        end
    end
--]]    
    
    local re_start,re_end
    re_start = nil 
    re_end = 0    
    for k,v in pairs(result[engine]) do        
        for k1, v1 in pairs(v) do
            if not re_start then
                re_start = v1[2]
            elseif re_start  > v1[2] then
                re_start = v1[2]
            end
            if re_end < v1[3] then
               re_end = v1[3]
            end
        end    
    end
    
    for k2,v2 in pairs(result[engine]) do        
        for k3, v3 in pairs(v2) do
            local tmp = {}
            tmp[k3] = v3
            tmp.__WEIGHT__ = 1.0
            tmp.__RE_START__ = re_start
            tmp.__RE_END__ = re_end
            tmp.__NAME__ = string.upper(engine)
            tmp.__SEQ__ = 0
            tmp.__ID__ = 0    
            table.insert(lex_result.tokens,tmp)
            lex_result.nTokens = lex_result.nTokens + 1
        end
    end 
    return lex_result
end
    
function M:process_query_lmlex(domain,lex_result)
    local data ={}
    local lex_output;
    local cfg = {
        model_fn = ""
        }
    local output
    local lmlex_output = {}
    
    if self.db.lmlex[domain] then        
        lex_output = self:process_lmlex_query_lex(domain,self.processor.input)                
        data.input = self.processor.input
        
        cfg.model_fn = self.db.lmlex[domain].ngram.fn
        cfg.prob_threshold = self.db.lmlex.prob_threshold
        cfg.oov_pen = self.db.lmlex.oov_pen
        cfg.debug = self.db.lmlex.debug
        
        self:preload_engine_cached(domain, "lmlex", cfg )        
        data.arc,data.num = self:prepare_lmlex_data(domain,lex_output)        
        --table.print(data)
        if data.num and data.num > 0 then            
            --table.print(cfg)   
            --output = self:run_engine("lmlex", cfg, data )
            output = self:run_engine_cached( domain,"lmlex", cfg, data )
        end
        --table.print(output)  
        lmlex_output.lmlex = {}
        if output and table.maxn(output.lmlex)>0 then
            for i=1, table.maxn(output.lmlex) do
                for k, v in pairs(output.lmlex[i]) do                    
                    local tmp = {}
                    --tmp[self.db.lmlex[domain].mapping[k]] = v
                    tmp[k] = v                    
                    table.insert(lmlex_output.lmlex,tmp)                                    
                end
                --table.insert(lmlex_output.lmlex,tmp)
            end
                        
            if lmlex_output.lmlex then
                self:merge_with_lex_result(lex_result,"lmlex",lmlex_output)
            end
            --[[
            --临时解决music里短句单个slot的问题            
            if lmlex_output.lmlex and table.maxn(lmlex_output.lmlex) > 1 then
                self:merge_with_lex_result(lex_result,"lmlex",lmlex_output)
            else
                local len
                if lmlex_output.lmlex[1] then
                    for k, v in pairs(lmlex_output.lmlex[1]) do
                        len = v[3] - v[2]
                    end
                end
                if len and len >= string.len(self.processor.input)/2 then
                    self:merge_with_lex_result(lex_result,"lmlex",lmlex_output)
                end
            end
            --]]
            --table.print(lex_result)
        end            
    end
    
    --if self.debug then
    --    table.print(lex_result)
    --end
    return lex_result
end

function M:second_pass_process_query_crf(domain,lex_result,inputstr)
    local data ={}
    local cfg = {
        model_fn = ""
        }
    local output
    local crf_output = {}

    if self.db.crf[domain] then
        cfg.model_fn = self.db.crf[domain].model_fn.fn
        if self.db.crf[domain].dict_tbl[1] and self.db.crf[domain].dict_tbl[1].fn then
            cfg.dict_fn = self.db.crf[domain].dict_tbl[1].fn
            cfg.dict_str_len = self.db.crf[domain].dict_tbl[1].str_len
        else
            cfg.dict_fn = "";
            cfg.dict_str_len = 0;
        end
        cfg.use_mmap = self.db.crf.use_mmap
        output = self:run_engine_cached(domain,"crf", cfg, inputstr )
    end

    crf_output.crf = {}
    if output and table.maxn(output.crf)>0 then
        for i=1, table.maxn(output.crf) do
            for k, v in pairs(output.crf[i]) do
                local tmp = {}
                if self.db.crf[domain].mapping[k] then
                    tmp[self.db.crf[domain].mapping[k]] = v
                    table.insert(crf_output.crf,tmp)
                end
            end
        end

        self:merge_with_lex_result(lex_result,"crf",crf_output)
        --[[
        if self.db.crf[self.domain].use_lua_merge then
            local func = self.processor_cb[self.db.crf[self.domain].merge_slots_cb]
            if func then
                func(self.processor_cb,lex_result,crf_output)
            else
                print("error: cann't find merge_slots_ cb function")
            end
        else
            self:merge_with_lex_result(lex_result,"crf",crf_output)
        end
        --]]
    end

    --if self.debug then
    --    table.print(lex_result)
    --end
    return lex_result
end

function M:process_query_crf(domain,lex_result)
    local data ={}
    local cfg = {
        model_fn = ""
        }
    local output
    local crf_output = {}
    
    if self.db.crf[domain] then
        cfg.model_fn = self.db.crf[domain].model_fn.fn
        if self.db.crf[domain].dict_tbl[1] and self.db.crf[domain].dict_tbl[1].fn then
            cfg.dict_fn = self.db.crf[domain].dict_tbl[1].fn
            cfg.dict_str_len = self.db.crf[domain].dict_tbl[1].str_len             
        else
            cfg.dict_fn = "";
            cfg.dict_str_len = 0;
        end
        cfg.use_mmap = self.db.crf.use_mmap
        output = self:run_engine_cached(domain,"crf", cfg, self.processor.input )        
    end
    
    crf_output.crf = {}    
    if output and table.maxn(output.crf)>0 then
        for i=1, table.maxn(output.crf) do
            for k, v in pairs(output.crf[i]) do
                local tmp = {}
                if self.db.crf[domain].mapping[k] then
                    tmp[self.db.crf[domain].mapping[k]] = v
                    table.insert(crf_output.crf,tmp)
                end                
            end          
        end
        
        self:merge_with_lex_result(lex_result,"crf",crf_output)
        --[[    
        if self.db.crf[self.domain].use_lua_merge then
            local func = self.processor_cb[self.db.crf[self.domain].merge_slots_cb]
            if func then
                func(self.processor_cb,lex_result,crf_output)
            else
                print("error: cann't find merge_slots_ cb function")
            end
        else    
            self:merge_with_lex_result(lex_result,"crf",crf_output)
        end 
        --]]       
    end
    
    --if self.debug then
    --    table.print(lex_result)
    --end
    return lex_result
end

function M:process_query_linear(domain)
    local cfg
    local output
    local ret
    
    if self.db.linear and self.db.linear[domain] then
        cfg = self.db.linear[domain].config           
        output = self:run_engine_cached(domain,"linear", cfg, self.processor.input )        
    end
    
    if output and output.linear and output.linear.label then        
        if self.db.linear[domain].class_id_map[output.linear.label] then
            ret = self.db.linear[domain].class_id_map[output.linear.label]           
        end
    end
    
    if not ret then
        ret = self.data.default_domain
    end

    if self.debug then
        print("linear:",ret)
    end
    return ret
end

function M:process_query_domain( data )
    local input
    local use_session_domain;
    local use_force_domain
    
    input = data.reftext    
    use_session_domain = self.opts.use_session_domain
    use_force_domain = self.opts.use_force_domain
    self.opts.use_session_domain = false
    self.opts.use_force_domain = false
    self:query_domain( input )
    self.opts.use_session_domain = use_session_domain        
    self.opts.use_force_domain = use_force_domain
end

local function slot_cmp(a,b)
    local ret = false
    if a.__WEIGHT__ > b.__WEIGHT__ then
        ret = true
    elseif a.__WEIGHT__ == b.__WEIGHT__ then
        if a.__SEQ__ == b.__SEQ__ then
            if a.__SLOT_START__ < b.__SLOT_START__ then
                ret = true
            elseif a.__SLOT_START__ == b.__SLOT_START__ then
                if a.__SLOT_END__ < b.__SLOT_END__ then
                    ret = true
                elseif a.__SLOT_END__ == b.__SLOT_END__ then
                    ret = a.__SORT__ < b.__SORT__
                end
            end
        else
            ret = a.__SEQ__ < b.__SEQ__
        end
    end
    return ret
end

function M:lex_slots_to_act( slots, sem, act )
    local cnt = 0
    if table.maxn(slots) > 0 then
        table.sort(slots,slot_cmp ) -- 按权重从高到低排序                              
        for k,v in pairs(slots) do            
            local tmp = {}       
           
            tmp["key"] = v.__KEY__
            tmp["data"]={}
            tmp["data"]["__WEIGHT__"]     = v.__WEIGHT__
            tmp["data"]["__RE_START__"]   = v.__RE_START__
            tmp["data"]["__RE_END__"]     = v.__RE_END__
            tmp["data"]["__SLOT_START__"] = v.__SLOT_START__
            tmp["data"]["__SLOT_END__"]   = v.__SLOT_END__
            tmp["data"]["__NAME__"]       = v.__NAME__
            tmp["data"]["__SEQ__"]        = v.__SEQ__
            tmp["data"]["__VALUE__"]      = v[v.__KEY__][1]

            local found = false                
            for key,value in pairs(act) do
                if tmp.key == value.key then
                    tmp.data.__SORT__ = value.data.__SORT__
                    if not found then
                        local cmp_value = false 
                        found = true
                        cmp_value = self.processor_cb:is_merge_by_value( sem.domain, tmp.key )                        
                        if cmp_value then
                            local weight
                            if tmp.data.__WEIGHT__ > value.data.__WEIGHT__ then
                                weight = tmp.data.__WEIGHT__
                            else
                                weight = value.data.__WEIGHT__
                            end
                            if (tmp.data.__SLOT_END__ >= value.data.__SLOT_END__ and tmp.data.__SLOT_START__ < value.data.__SLOT_START__) 
                               or (tmp.data.__SLOT_END__ > value.data.__SLOT_END__ and tmp.data.__SLOT_START__ <= value.data.__SLOT_START__) then
                                tmp.data.__WEIGHT__ = weight                                
                                act[key] = nil
                                found = false
                            elseif (tmp.data.__SLOT_END__ <= value.data.__SLOT_END__ and tmp.data.__SLOT_START__ > value.data.__SLOT_START__) 
                               or (tmp.data.__SLOT_END__ < value.data.__SLOT_END__ and tmp.data.__SLOT_START__ >= value.data.__SLOT_START__) then
                                value.data.__WEIGHT__ = weight
                                break  
                            elseif tmp.data.__SLOT_END__ == value.data.__SLOT_END__ and tmp.data.__SLOT_START__ ==  value.data.__SLOT_START__ then
                                if tmp.data.__VALUE__ ~= value.data.__VALUE__ then 
                                    if string.find(tmp.data.__VALUE__,value.data.__VALUE__) then
                                        tmp.data.__WEIGHT__ = weight
                                        act[key]=nil
                                        found = false
                                    elseif string.find(tmp.data.__VALUE__,value.data.__VALUE__) then
                                        value.data.__WEIGHT__ = weight
                                        break
                                    elseif tmp.data.__WEIGHT__ > value.data.__WEIGHT__ then
                                        --tmp.data.__WEIGHT__ = weight
                                        --found = false                                        
                                        act[key] = nil
                                        found = false
                                    else
                                        break
                                    end
                                else
                                    if tmp.data.__WEIGHT__ > value.data.__WEIGHT__ then
                                        value.data.__WEIGHT__ = tmp.data.__WEIGHT__                                        
                                    end 
                                    break
                                end
                            --[[
                            elseif tmp.data.__SLOT_END__ - tmp.data.__SLOT_START__ > value.data.__SLOT_END__ - value.data.__SLOT_START__ then
                                act[key] = nil
                                found = false
                            elseif tmp.data.__SLOT_END__ - tmp.data.__SLOT_START__ < value.data.__SLOT_END__ - value.data.__SLOT_START__ then
                                value.data.__WEIGHT__ = weight
                                break
                            --]]
                            else                                  
                                if tmp.data.__WEIGHT__ > value.data.__WEIGHT__ then
                                    act[key] = nil
                                    found = false
                                elseif tmp.data.__WEIGHT__ == value.data.__WEIGHT__ then
                                    if tmp.data.__SLOT_END__ ~= value.data.__SLOT_END__ or tmp.data.__SLOT_START__ ~=  value.data.__SLOT_START__ then
                                        found = false
                                        break
                                    else
                                        if tmp.data.__VALUE__ ~= value.data.__VALUE__ then
                                            found = false
                                            break
                                        end                                         
                                    end
                                else
                                    break
                                end
                            end  
                        else                                
                            if tmp.data.__WEIGHT__ > value.data.__WEIGHT__ then
                                act[key] = tmp
                            elseif tmp.data.__WEIGHT__ == value.data.__WEIGHT__ then                                    
                                if tmp.data.__SLOT_END__ ~= value.data.__SLOT_END__ or tmp.data.__SLOT_START__ ~=  value.data.__SLOT_START__ then
                                    if tmp.data.__NAME__ ~= value.data.__NAME__ then                                       
                                        found = false
                                    elseif tmp.data.__SLOT_END__ > value.data.__SLOT_END__ and tmp.data.__SLOT_START__ <= value.data.__SLOT_START__ then
                                        act[key]  = tmp
                                        break
                                    elseif tmp.data.__SLOT_END__ >= value.data.__SLOT_END__ and tmp.data.__SLOT_START__ < value.data.__SLOT_START__ then
                                        act[key]  = tmp
                                        break
                                    else --if tmp.data.__SLOT_START__ > value.data.__SLOT_END__ or tmp.data.__SLOT_END__ <= value.data.__SLOT_START__ then 
                                        found = false
                                    end                                                                                
                                elseif tmp.data.__NAME__ ~= value.data.__NAME__ then
                                    if tmp.data.__VALUE__ and tmp.data.__VALUE__ ~= "" and tmp.data.__VALUE__ ~= value.data.__VALUE__ then
                                        if value.data.__VAULE__ == "" then
                                            act[key] = tmp
                                            break
                                        else
                                            found = false
                                        end
                                    else
                                        if tmp.data.__RE_END__ - tmp.data.__RE_START__ > value.data.__RE_END__ - value.data.__RE_START__ then
                                            act[key] = nil
                                            found = false
                                        else
                                            break
                                        end
                                    end                                         
                                else
                                    if not tmp.data.__VALUE__ then
                                        found = false
                                    elseif tmp.data.__VALUE__ == "" then
                                        found = false
                                    elseif string.len(tmp.data.__VALUE__) < string.len(value.data.__VALUE__) then
                                    --[[
                                    elseif tmp.data.__SLOT_END__ > value.data.__SLOT_END__ and tmp.data.__SLOT_START__ <= value.data.__SLOT_START__  then                                        
                                        act[key] = tmp
                                    elseif tmp.data.__SLOT_END__ >= value.data.__SLOT_END__ and tmp.data.__SLOT_START__ < value.data.__SLOT_START__  then                                        
                                        act[key] = tmp
                                    elseif tmp.data.__SLOT_END__ ~= value.data.__SLOT_END__ or tmp.data.__SLOT_START__ ~= value.data.__SLOT_START__  then
                                    --]]
                                        found = false
                                    elseif string.len(tmp.data.__VALUE__) > string.len(value.data.__VALUE__) then
                                        act[key]  = nil
                                        found = false        
                                    elseif string.len(tmp.data.__VALUE__) == string.len(value.data.__VALUE__) then
                                        if tmp.data.__VALUE__ ~= value.data.__VALUE__ then
                                           found = false
                                        end             
                                    end
                                    break
                                end                                
                            else                                                                        
                                break
                            end
                        end
                    else                                                                                    
                        act[key] = nil
                    end
                end
            end
                 
            if not found then                
                if not tmp.data.__SORT__ then
                    cnt = cnt + 1 
                    tmp.data.__SORT__ = cnt
                end
                table.insert(act,tmp)                                                            
            end                        
        end
    end
end

function M:statistics_slots_to_act( slots, sem, act )    
    local cnt = table.maxn(act)
    if table.maxn(slots) > 0 then
        local ignore_key_list = {}                              
        for k,v in pairs(slots) do            
            local tmp = {}       
            local ignore = false            
            tmp["key"] = v.__KEY__
            tmp["data"]={}
            tmp["data"]["__WEIGHT__"]   = v.__WEIGHT__
            tmp["data"]["__RE_START__"] = v.__RE_START__
            tmp["data"]["__RE_END__"]   = v.__RE_END__            
            tmp["data"]["__SLOT_START__"] = v.__SLOT_START__
            tmp["data"]["__SLOT_END__"]   = v.__SLOT_END__
            tmp["data"]["__NAME__"]       = v.__NAME__
            tmp["data"]["__SEQ__"]        = v.__SEQ__
            tmp["data"]["__VALUE__"]      = v[v.__KEY__][1]
            
            --if ignore_key_list[tmp.key] then
            --    ignore = true
            --else             
            for k1, v1 in pairs(act) do                                
                if tmp.key == v1.key then
                    tmp.data.__SORT__ = v1.data.__SORT__
                --[[
                    if v1.data.__VALUE__ ==  "" then
                        ignore = true
                    elseif v1.data.__VALUE__ == tmp.data.__VALUE__ and v1.data.__SLOT_START__ == tmp.data.__SLOT_START__ and v1.data.__SLOT_END__ == tmp.data.__SLOT_END__ then
                        ignore = true                            
                    end
                --]]
                    --if (v1.data.__VALUE__ == tmp.data.__VALUE__ and v1.data.__SLOT_START__ == tmp.data.__SLOT_START__) or
                    if (v1.data.__VALUE__ == tmp.data.__VALUE__) or 
                       (v1.data.__VALUE__ ~= "" and v1.data.__SLOT_START__ <= tmp.data.__SLOT_START__ and v1.data.__SLOT_END__ >= tmp.data.__SLOT_END__) then
                         --ignore_key_list[tmp.key] = true
                         ignore = true
                         break
                    end
                    
                    --tmp.data.__WEIGHT__ = v1.data.__WEIGHT__ 
                end
            end
            --end
            
            if not ignore then
                if tmp.data.__NAME__ == "LMLEX" then
                    tmp.data.__RE_START__ = tmp.data.__SLOT_START__
                    tmp.data.__RE_END__   = tmp.data.__SLOT_END__
                elseif tmp.data.__NAME__ == "CRF" then
                    tmp.data.__RE_START__ = nil
                    tmp.data.__RE_END__   = nil
                end
                if not tmp.data.__SORT__ then
                    cnt = cnt + 1
                    tmp.data.__SORT__ = cnt
                end
                table.insert(act,tmp)
            end     
        end                  
    end    
end

local function sort_by_slot_start( data1, data2 )
    local ret
    local s1, s2       
    s1 = data1.data.__SLOT_START__
    s2 = data2.data.__SLOT_START__
    if s1==s2 then
        if data1.data.__SLOT_END__ == data2.data.__SLOT_END__ then
            if data1.data.__SEQ__ ==  data2.data.__SEQ__ then
                if data1.data.__SORT__ == data2.data.__SORT__ then
                    ret = data1.data.__SEQ__ < data2.data.__SEQ__
                else
                    ret = data1.data.__SORT__ > data2.data.__SORT__
                end
            else
                if data1.data.__SORT__ == data2.data.__SORT__ then
                    ret = data1.data.__SEQ__ < data2.data.__SEQ__                         
                else
                    ret = data1.data.__SORT__ < data2.data.__SORT__
                end
            end
        else            
            ret = data1.data.__SLOT_END__ < data2.data.__SLOT_END__
        end
    else
        ret = s1 < s2
    end
    return ret
end

local function sort_by_same_key(data1, data2)
    local ret
    local len1 = data1.data.__SLOT_END__ - data1.data.__SLOT_START__ 
    local len2 = data2.data.__SLOT_END__ - data2.data.__SLOT_START__
    if len1 == len2 then
        ret =  sort_by_slot_start(data1,data2)
    else
        ret =  len1 > len2
    end
    return ret
end

local function sort_act( data1, data2 )
    local ret
    if data1.data.__SORT__ == data2.data.__SORT__ then
        if data1.key == data2.key then
            ret = sort_by_same_key(data1,data2)
        else
            ret = sort_by_slot_start(data1,data2)
        end
    else
        ret = data1.data.__SORT__ < data2.data.__SORT__
    end
    return ret
end
        
local function sort_by_slot_weight(data1, data2)
    local is_stat = false
    local data1_is_stat = false
    local data2_is_stat = false
    local ret

    if data1.data.__NAME__ == "CRF" or data1.data.__NAME__ == "LMLEX" then
        data1_is_stat = true
        is_stat = true
    end
    if data2.data.__NAME__ == "CRF" or data2.data.__NAME__ == "LMLEX" then
        data2_is_stat = true
        is_stat = true
    end

    if data1_is_stat and not data2_is_stat then
        ret = 0
    elseif not data1_is_stat and data2_is_stat then
        ret = 1    
    else
        ret = nil
    end
 
    if data1.data.__NAME__ == data2.data.__NAME__ then
        is_stat = true
    end

    if is_stat then
        if ret and data1.data.__KEY__ ~= data2.data.__KEY__ then
            return ret > 0
        else
            return sort_by_slot_start(data1,data2)
        end
    elseif data1.data.__WEIGHT__ == data2.data.__WEIGHT__ then
        if data1.data.__KEY__ == data2.data.__KEY__ then
            return sort_by_same_key( data1, data2 )
        else
            return data1.data.__SORT__ < data2.data.__SORT__
        --else
        --    return data1.data.__SEQ__ < data2.data.__SEQ__
        end
    else
        return data1.data.__WEIGHT__ > data2.data.__WEIGHT__
    end
end    

function M:slots_update_by_case( sem, tokens )
    local act = {}
    local slots = {}
    local statistics_slots = {}    
    local tmp_sem    
    local slot_cnt = 0
    local stat_cnt = 0
    
    debug_str = nil
    if table.maxn(tokens)>0 then
        -- table.sort(tokens,function(a,b) return a.__WEIGHT__ > b.__WEIGHT__ end)
    end
    
    for i,token in pairs(tokens) do
        
        if token.__NAME__ == "CRF" or token.__NAME__ == "LMLEX" then            
            debug_str = "Rule: <"..token.__NAME__.."> :[__RE_START__="..tostring(token.__RE_START__)..",__RE_END__="..tostring(token.__RE_END__).."]"            
        else            
            debug_str = "Rule: <"..token.__NAME__.."> :[__RE_START__="..tostring(token.__RE_START__)..",__RE_END__="..tostring(token.__RE_END__).."]"
        end
        
        for k,v in pairs(token) do
            if k ~= "__WEIGHT__" and k ~= "__RE_START__" and k~= "__RE_END__" and k~= "__KEY__" and k~="__NAME__" and k~="__SEQ__" and k~= "__ID__" then
                
                for s in string.gmatch(k,"([^:]+)") do
                    local tmp = {}
                
                    tmp.__WEIGHT__   = token.__WEIGHT__
                    tmp.__RE_START__ = token.__RE_START__
                    tmp.__RE_END__   = token.__RE_END__                
                    tmp.__NAME__     = token.__NAME__
                    if token.__SEQ__ then
                        tmp.__SEQ__      = token.__SEQ__
                    else
                        tmp.__SEQ__ = 0
                    end

                    tmp.__KEY__ = s
                    if type(v)=="string" then
                        tmp[s]={[1]=v,[2]=-1,[3]=-1}
                        tmp.__SLOT_START__ = -1
                        tmp.__SLOT_END__   = -1
                    else
                        tmp[s] = v
                        tmp.__SLOT_START__ = v[2]
                        tmp.__SLOT_END__   = v[3]
                    end
                    
                    debug_str = debug_str.."\n    "..s..":[__VALUE__="..tmp[s][1]..",__SLOT_START__="..tostring(tmp[s][2])..",__SLOT_END__="..tostring(tmp[s][3])..",__WEIGHT__="..tostring(token.__WEIGHT__).."]"
                
                    if token.__NAME__ == "CRF" or token.__NAME__ == "LMLEX" then
                        debug_str = debug_str.."\n--=--=--=--=--=--=--=--=--=--=--=--=--=--=--=--=--=--=--=--=--=--=--=--=--=--=--=--=--=--=--=--"
                        tmp.__SORT__ = stat_cnt                    
                        table.insert(statistics_slots,tmp)
                        stat_cnt = stat_cnt + 1
                    else               
                        if tmp[tmp.__KEY__][1] ~= "__NIL__" then
                            tmp.__SORT__ = slot_cnt              
                            table.insert(slots,tmp)
                            slot_cnt = slot_cnt + 1
                        end
                    end
                end
            end
        end
        
        --debug_str = debug_str.."__RE_START__="..tostring(token.__RE_START__)..",__RE_END__="..tostring(token.__RE_END__)
        self:trace(debug_str)
        
    end
    
    if not debug_str then
        self:trace("null")    
    end
    
    self:lex_slots_to_act(slots,sem, act)
    self:statistics_slots_to_act(statistics_slots, sem, act)
    
    local cnt = 0
    if table.maxn(act) > 0 then
        local tmp
        for k,v in pairs(act) do
 --           if v.data.__VALUE__ == "" then
 --                act[k] = nil
 --           else
                if not tmp then
                    tmp = {}
                end
--                v.data.__SORT__ = cnt
                table.insert(tmp,v)
--                cnt = cnt + 1
--            end            
        end
        act = tmp
    end

    if not act then
        act = {}
    end
    
    --table.print(sem)
    --table.print(act)    
    if self.processor_cb then
       if table.maxn(act) > 1 then
--           table.sort(act,sort_by_slot_start)
           table.sort(act,sort_act)
       end           
--       table.print(act)
       tmp_sem, act = self.processor_cb:reform_cb_entry(sem,act)
    end
    --table.print(tmp_sem)
    --table.print(act)
    
    if not act or tmp_sem.domain == "@" then         
        return nil,0
    end
    
    local slots = {}        
    local cnt=0
    local key_rcd = {}

    for key,value in pairs(act) do
        if value and value.data and value.data.__VALUE__ and value.data.__VALUE__ ~= "" and not key_rcd[value.key] then
            local slot = {} 
            key_rcd[value.key] = true               
            slot[value.key] = {[1]=value.data.__VALUE__, [2]=value.data.__SLOT_START__,[3]=value.data.__SLOT_END__}        
            slot.__WEIGHT__ = value.data.__WEIGHT__
            table.insert(slots,slot)
            cnt = cnt+1
        end
    end 
    
    --if tmp_sem.domain == "@" then        
    --    slots = nil
    --end
               
    return slots,cnt
end

function M:slots_update_process( output, nbest )
    local sem = {}
    local act = {}
    local end_time
    local slots = {}
    
    if not output.tokens then
        return output,nbest
    end
    
    local tokens = {}
    local cnt
                    
    sem.domain       = self.domain 
    sem.source       = self.source   
    sem.input        = self.processor.input
    sem.domain_nbest = self.nbest
    sem.use_2pass    = self.session.use_2pass
    sem.dlg_domain   = self.session.dlg_domain
    sem.jump_domain  = self.jump_domain
        
    tokens,cnt = self:slots_update_by_case(sem,output.tokens)
        
    if tokens then
        output.tokens = tokens
        output.nTokens = 1
    else
        output.nTokens = 0
    end
    
    if sem.domain == "@" then
        --print("delele",self.domain)
        self.domain = "@"
    end       
        
    if output.nTokens == 0 then
        output.tokens = {}        
    else
        output.tokens = tokens
        if table.maxn(nbest) > 0 then
            for i=1,table.maxn(nbest) do 
                local cnt
                tokens = {}                
                sem.domain = self.nbest[i].domain
                
                debug_str = "-=- query lex -=- \nnbest domain="..sem.domain
                self:trace(debug_str)
                                                
                tokens,cnt = self:slots_update_by_case(sem,nbest[i].tokens)
                
                if tokens then
                    nbest[i].nTokens = 1
                    nbest[i].tokens= tokens    
                else                    
                    nbest[i].nTokens = 0                                             
                end
                
                if sem.domain == "@" then
                    --print("delele",self.nbest[i].domain)
                    nbest[i] = nil
                    self.nbest[i] = nil
                else
                    nbest[i].tokens = tokens
                end
            end
        end
        
        if table.maxn(nbest) == 0 then
            nbest = nil
            self.nbest = nil
        end
    end
        
    return output,nbest
end

local function delindex(semantics)

    if not semantics['semantics']
    then
        return semantics
    end
    
    if not semantics['semantics']['request']
    then
        return semantics
    end
    
    for item,v in pairs(semantics['semantics']['request']['param']) do      
        if v[1]
        then
            semantics['semantics']['request']['param'][item] = v[1]
        end
    end
    
    if not semantics['semantics']['nbest']
    then
        return semantics
    end
    
    for k,nbest in pairs(semantics['semantics']['nbest']) do
        for item1, v1 in pairs(nbest['request']['param']) do
            if v1[1]
            then
                nbest['request']['param'][item1] = v1[1]
            end
        end 
    end
    
    return semantics
end

function M:process( data )
    local result,nbest
    local start_time, end_time 

    start_time = self.engines["core"]:get_time()
    local func = "query LM"
    if data.func then
        if data.func == "query domain" then
            func = "query domain"
        end
    end
    
    if data.pinyin then
        self.processor.pinyin = data.pinyin        
    else
        self.processor.pinyin = ""        
    end
    self.modules["reform"]:set_pinyin(self.processor.pinyin)
    
    if func == "query LM" then     
        if data.reftext then
            local domain=nil
            domain = self:get_session_domain()
            result,nbest = self:process_query_lex(domain,data);
            if self.debug then
                print("Post.......................................")
                self:print_data(result)
                print("Post nbest.......................................")
                self:print_data(nbest)
            end            
            if result and self.use_lmlex then                
                self:process_query_lmlex(self.domain,result)
                if self.debug then
                    print("lmlex..........................................")
                    self:print_data(result)
                end                
                if self.use_wtk_version and nbest then
                    for k1, v1 in pairs(nbest) do
                        nbest[k1] = self:process_query_lmlex(self.nbest[k1].domain,v1)
                    end
                    if self.debug then
                        print("lmlex nbest..........................................")
                        self:print_data(nbest)
                    end
                end
            end
            
            if result and self.use_crf then
                if self.debug then
                    print("crf..........................................")
                end
                self:process_query_crf(self.domain,result)
                if self.use_wtk_version and nbest then
                    for k2, v2 in pairs(nbest) do
                        nbest[k2] = self:process_query_crf(self.nbest[k2].domain,v2)
                    end
                end
            end
            
            if self.use_wtk_version then
                result,nbest = self:slots_update_process(result,nbest)
                if self.debug then
                    print("Update.......................................")
                    self:print_data(result)
                    print("Update nbest.......................................")
                    self:print_data(nbest)
                end
            end
                        
            if result and self.opts.use_merge and not self.use_wtk_version then
                result = self.modules["reform"]:merge_tokens(result)
                if self.debug then
                    print("Merge.......................................")
                    self:print_data(result)
                end                                
            end
                            
            if result and self.opts.use_reform then
                local param = {}
                param.skill = self.sys.name
                param.domain = self.domain
                param.dlg_domain = self:get_session_dlg_domain()
                end_time  = self.engines["core"]:get_time()
                param.time  = end_time-start_time
                param.res   = self.sys.res
                param.input = self.input
                param.jump_domain = self.jump_domain
                if self.use_wtk_version or self.output_wtk_format then
                    param.nbest = self.nbest                    
                    result = self.modules["reform"]:reform_output_with_wtk_format(param,result,nbest)
                    if self.use_wtk_version then
                        if self.reform_ves then                        
                            result = self.reform_ves:version_transform(self.request_version,self.sys.res,result,self.use_index)
                        end
                        if not self.use_index then
                            result = delindex(result)
                        end
                    end
                else
                    result = self.modules["reform"]:reform_output(param,result)    --转为nlu上层需要的json格式                                    
                end
                                                    
                self.nbest = {}
                if self.debug then                
                    print("Reform.......................................")
                    self:print_data(result)
                end
            end            
        end
    else
        if data.reftext then
            local domain=self.key.domain
            local param = {}
            
            self:process_query_domain(data)                        
            param.skill      = self.sys.name
            param.domain     = self.domain
            param.weight     = self.weight
            end_time         = self.engines["core"]:get_time()
            param.time       = end_time-start_time
            param.res        = self.sys.res
            param.input      = self.input
            param.dlg_domain = self:get_session_dlg_domain() 
            
            if self.domain == self.key.no_domain then
                domain = nil
            else
                domain = self.domain
            end
            result = self.modules["reform"]:reform_domain_output(param,domain,self.nbest)    --转为nlu上层需要的json格式
            self:reset_domain()
            if self.debug then
                print("Reform.......................................")
            end                            
        end    
    self.processor.input = ""           
    end
    return result
end

--************************************************************************--
--                            domain functions                            --
--************************************************************************--
function M:reset_domain()
    self.domain  = "@" -- domain is using.
    self.weight  = 0.0
    self.nbest   = {}
end

function M:get_force_domain( )
    local ret
    if self.opts.use_force_domain then
        ret = self.data.force_domain
    else
        ret = self.key.no_domain
    end
    return ret
end

function M:set_fields( num, fieldset )
    self.data.fields.num = num;
    self.data.fields.set = fieldset;
end

function M:get_field( fieldname )    
    return self.data.fields.set[fieldname];
end

function M:field_is_existed( fieldname )
    local ret = false;    
    if( self:get_field(fieldname) and self:get_field(fieldname) ~= "" ) or fieldname == "null" then
        ret = true;
    end
    return ret
end   

function M:get_domain_from_slots( token )
    local weight,domain,act
    if token.__WEIGHT__ then    
        weight = token.__WEIGHT__
    end
    if token.domain then        
        domain = token.domain
        if domain == "@" then
            domain = "null"
        end
        act = {}
        act.key = "domain"
        act.data = {}
        act.data.__WEIGHT__   = weight
        act.data.__NAME__     = token.__NAME__
        act.data.__SEQ__      = token.__SEQ__
        act.data.__RE_START__ = token.__RE_START__
        act.data.__RE_END__   = token.__RE_END__
        act.data.__VALUE__    = domain
    else
        domain = self.data.default_domain
        act = {}
        act.key = "domain"
        act.data = {}
        act.data.__VALUE__n = domain
    end
    return domain,weight,act
end

function M:is_existed_in_nbest(domain,nbest)
    local ret = false
    for k,v in pairs(nbest) do
        if v.domain == domain.domain then
            ret = true
            if v.weight < domain.weight then
                v.weight = domain.weight
            end
        end
    end
    return ret
end


local function domain_cmp(a,b)
    local ret = false
    if a.weight > b.weight then
        ret = true
    elseif a.weight == b.weight then
        ret = a.seq < b.seq 
    end
    return ret
end

-- domain 优先级规则：
-- 1. 权重最高
-- 2. 匹配规则长度
-- 3. 是否与dlg_domain同名
-- 4. lex在规则文件中的顺序,后面的优先级大于前面的
function M:get_domain_from_tokens( output )
    local tbl
    local weight,domain,nbest,name,seq,act
    local token_idx
    
    domain = self.data.default_domain
    weight = 0
    seq = 0
    name = ""
    nbest = {}
    tbl = output  
    
    if tbl.nTokens > 1 then
        table.sort(tbl.tokens,function(a,b) return a.__WEIGHT__>b.__WEIGHT__ end)
    end    
    
    for i=1, tbl.nTokens do
        debug_str = "Rule: <"..tbl.tokens[i].__NAME__..">"
                
        if i == 1 then
            if tbl.tokens[1] then
                domain,weight,act = self:get_domain_from_slots(tbl.tokens[1])
                name = tbl.tokens[1].__NAME__
                seq = tbl.tokens[1].__SEQ__
                token_idx = 1
                
                debug_str = debug_str.."\n    domain:[__VALUE__="..domain..",__WEIGHT__="..tostring(weight).."]"
                
                if not self:is_in_used_domain_set(domain) or not self:field_is_existed(domain) then
                    domain = self.data.default_domain
                    weight = 0
                    name = ""
                    seq = 0
                    act = {}
                    act.key = "domain"
                    act.data = {}
                    act.data.__NAME__   = name
                    act.data.__SEQ__    = seq
                    act.data.__WEIGHT__ = weight
                    act.data.__VALUE__  = domain
                end 
            else
                domain = self.data.default_domain
                weight = 0
                name = ""
                seq = 0
                act = {}
                act.key= "domain"
                act.data = {}
                act.data.__NAME__   = name
                act.data.__SEQ__    = seq
                act.data.__WEIGHT__ = weight
                act.data.__VALUE__  = domain
            end                         
        else
            local tmp = {}
            if tbl.tokens[i] then
                tmp.domain,tmp.weight,tmp.act = self:get_domain_from_slots(tbl.tokens[i])
                tmp.name = tbl.tokens[i].__NAME__
                tmp.seq = tbl.tokens[i].__SEQ__
                                
                debug_str = debug_str.."\n    domain:[__VALUE__="..tmp.domain..",__WEIGHT__="..tostring(tmp.weight).."]"
                                                                
                local is_swap = false;
                if self:is_in_used_domain_set(tmp.domain) and self:field_is_existed(tmp.domain) then
                    if tmp.weight > weight then
                        is_swap = true;    
                    elseif tmp.weight == weight then                        
                        if tmp.seq < seq then
                            is_swap = true
                        elseif not self.use_wtk_version then                        
                            if tbl.tokens[i].__RE_END__-tbl.tokens[i].__RE_START__ > tbl.tokens[token_idx].__RE_END__-tbl.tokens[token_idx].__RE_START__ then
                                is_swap = true
                            else
                                local dlg_domain
                                dlg_domain = self:get_session_dlg_domain();
                                if domain ~= dlg_domain and tmp.domain == dlg_domain then
                                    is_swap = true
                                end                                     
                            end
                        end
                    end
                    
                    if is_swap then
                        local swap = {}
                        swap.domain = tmp.domain
                        swap.weight = tmp.weight
                        swap.name = tmp.name   
                        swap.seq = tmp.seq                     
                        swap.act = tmp.act                     
                        tmp.domain = domain
                        tmp.weight = weight 
                        tmp.name = name   
                        tmp.seq = seq                    
                        tmp.act = act                    
                        domain = swap.domain
                        weight = swap.weight
                        name = swap.name
                        seq = swap.seq
                        act = swap.act
                        token_idx = i;
                    end
                    -- 由于best domain可能已经在nbest中（权重低先来,权重高后来的状况),所以nbest中有可能存在best domain
                    if tmp.domain ~= domain then --丢弃权重小于0.02的domain
                        if not self:is_existed_in_nbest(tmp,nbest) then
                            table.insert(nbest,tmp)
                        end
                    end
                end                        
            end                            
        end
        self:trace(debug_str)        
    end
    
    local tmp = {}
    if nbest then
        for k,v in pairs(nbest) do
            if v.domain ~= domain and v.domain ~= "null" and v.domain ~= "@" then
                table.insert(tmp,v)
            end
        end
        table.sort(tmp, domain_cmp )
        nbest = tmp                    
    end
    
    return domain,weight,nbest,act
end
--[[
function M:get_domain_from_tokens( output )
    local tbl
    local weight,domain,nbest
    
    domain = self.data.default_domain
    weight = 0
    nbest = {}
    tbl = output  
    for i=1, tbl.nTokens do
        if i == 1 then
            if tbl.tokens[1] then
                domain,weight = self:get_domain_from_slots(tbl.tokens[1])
                if not self:is_in_used_domain_set(domain) then
                    domain = self.data.default_domain
                    weight = 0
                end 
            else
                domain = self.data.default_domain
                weight = 0
            end
        else
            local tmp = {}
            if tbl.tokens[i] then
                tmp.domain,tmp.weight = self:get_domain_from_slots(tbl.tokens[i])
                if tmp.weight > weight then
                    local swap = {}
                    swap.domain = tmp.domain
                    swap.weight = tmp.weight
                    tmp.domain = domain
                    tmp.weight = weight
                    domain = swap.domain
                    weight = swap.weight
                end
                if self:is_in_used_domain_set(tmp.domain) then
                    if tmp.domain ~= domain and tmp.weight >= 0.2 then --丢弃权重小于0.2的domain
                        if not self:is_existed_in_nbest(tmp,nbest) then
                            table.insert(nbest,tmp)
                        end
                    end
                end                        
            end                            
        end
    end   
    
    return domain,weight,nbest
end
--]]

function M:query_domain( data )    
    local ret = self.data.default_domain    
    local field, result, domain
    
    self.weight = 0
    self.jump_domain = "@"
    
    debug_str = "-=- query domain -=-"
    self:trace(debug_str)    
    
    ret = self:get_force_domain()        
    if( ret == self.key.no_domain ) then        
        ret = self:get_session_domain();                
        if( ret == self.key.no_domain ) then                                    
            ret = self:get_session_dlg_domain();            
            if( ret ~= self.key.no_domain ) then                
                if( self:field_is_existed(self.key.jump_domain) ) then                
                    domain =  self.key.jump_domain
                else
                    if( self:field_is_existed(self.key.domain) ) then
                         domain = self.key.domain                    
                    else
                         self.domain = self.data.default_domain;
                         ret = self.domain
                         return ret
                    end
                end                
                result=self:process_in_domain(domain, data)
                if result.nTokens > 1 and result.tokens then
                    table.sort(result.tokens,function(a,b) return a.__SEQ__<b.__SEQ__ end)
                    --print("domain @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@")
                    --table.print(result)
                end
                self.domain,self.weight,self.nbest,self.domain_act = self:get_domain_from_tokens(result)
                ret = self.domain
                if domain == self.key.jump_domain then
                     self.jump_domain = ret
                end                   
                if self.use_linear and ret == self.data.default_domain then
                     ret= self:process_query_linear(domain)
                end
                if( ret == self.key.no_domain ) then
                     ret = self:get_session_dlg_domain();     
                end
            else                
                if( self:field_is_existed(self.key.domain) ) then                              
                    result = self:process_in_domain(self.key.domain, data)
                    if result.nTokens > 1 and result.tokens then
                        table.sort(result.tokens,function(a,b) return a.__SEQ__<b.__SEQ__ end)
                        --print("domain @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@")
                        --table.print(result)
                    end
                    self.domain,self.weight,self.nbest,self.domain_act = self:get_domain_from_tokens(result)                                        
                    ret = self.domain
                    if self.use_linear and ret == self.data.default_domain then
                        ret= self:process_query_linear(self.key.domain)
                    end
                else
                    ret = self.data.default_domain;
                end
            end
        end
    end
   
    if ret == "null" then    
        ret = "@"
    end
     
    self.domain = ret    
    return ret,self.weight;
end

--************************************************************************--
--                           session functions                            --
--************************************************************************--
function M:set_session(data) -- 传入json string设定session
    if( data.domain ) then
        data.domain = string.gsub(data.domain,"%.","+")        
        self:set_session_domain( data.domain );
    end
    if( data.dlg_domain ) then
        data.dlg_domain = string.gsub(data.dlg_domain,"%.","+")
        self:set_session_dlg_domain(data.dlg_domain);
    end
    if( data.used_domain_set ) then
        if data.used_domain_set.set then
            for i=1, table.maxn(data.used_domain_set.set) do
                data.used_domain_set.set[i] = string.gsub(data.used_domain_set.set[i],"%.","+")
            end
        end    
        self:set_session_used_domain_set(data.used_domain_set.num, data.used_domain_set.set);
    end
    if( data.lbs_city ) then
        self:set_session_lbs_city(data.lbs_city);
    end
    if data.use_2pass then
        self.session.use_2pass = data.use_2pass
    end
end

function M:reset_session()
    self.session.domain       = "@";  --"@" means no domain
    self.session.dlg_domain   = "@";
    self.session.used_domain_set.num = 0;
    self.session.used_domain_set.set = {};
    self.session.lbs_city = "";
    self.session.use_2pass = false    
end

function M:is_use_2pass()
    local ret = false
    if self.session.use_2pass then
        ret = self.session.use_2pass
    end
    return ret
end

function M:get_session_domain()
    local ret 
    if self.opts.use_session_domain then  
        ret = self.session.domain;
    else
        ret = self.key.no_domain
    end    
    return ret    
end

function M:set_session_domain(domain)    
    self.session.domain = domain;
end

function M:get_session_dlg_domain()
    return self.session.dlg_domain;
end

function M:set_session_dlg_domain(domain)
    self.session.dlg_domain = domain;
end

function M:set_session_used_domain_set( num, domainarray )
    self.session.used_domain_set.num = num;
    self.session.used_domain_set.set = domainarray;
end

function M:is_in_used_domain_set( domain )
    local ret = false
    if self.session.used_domain_set.num == 0 then
        ret = true
    else
        for i=1, self.session.used_domain_set.num, 1
        do
            if( domain == self.session.used_domain_set.set[i] ) then
                ret = true;
                break;
            end            
        end
    end
    return ret;
end

function M:get_session_lbs_city()
    return self.session.lbs_city;
end

function M:set_session_lbs_city(lbscity)
    self.session.lbs_city = lbscity;
end

--************************************************************************--
--                       nlucore interface function                       --
--************************************************************************--
--data.flows = ["lex","crf","lm","kv"] (default:"lex") flow是一个数组,内容的顺序是调用相应engine处理的顺序
--data.session.domain
--data.session.dgl_domain   = "@";
--data.session.used_domain_set.num = 0;
--data.session.used_domain_set.set = {};
--data.session.lbs_city. = "";
--data.session.use_2pass = true;
--data.skillid               "sk00001" 服务端使用feed功能必须提供skillid参数
--data.input.func            "query domain" or "query LM"(default:"query LM")
--data.input.reftext ==> input string
--data.input.pingyin
--data.wakeup.common.word
--data.wakeup.common.pingyin
--data.wakeup.custom.word
--data.wakeup.custom.pingyin
--data.opts.use_slot_index   "on" or "off"(default:"off")
--data.opts.use_stop_word    "on" or "off"(default:"on")
--data.opts.use_force_domain "on" or "off"(default:"on") 
--data.opts.use_reform       "on" or "off"(default:"on")
--data.opts.use_merge        "on" or "off"(default:"on")
--data.request_version = "2017.8.25.09:50:01"
function M:feed(data) -- data是table,不需要转json string
    local result;
    
    if data.skillid then
        self.skillid = data.skillid
    else
        self.skillid = ""
    end
            
    if data.session then	      
        self:set_session(data.session)
    end
		
    if data.opts then
        self:set_opts( data.opts )
    end
    
    if data.wakeup then
        self.modules["pre"]:set_wakeup_word(data.wakeup)
    end    		
		-- opts handler
		-- wakeup handler
    if data.request_version then
        self.request_version = data.request_version
    end
    if data.output_format then
        self.output_format = data.output_format
    end
		
    if data.input then

        self.input = data.input.reftext
        if self.processor_cb.reform_crf_entry then
            result = self:local_process(data.input)
        else
            result = self:process(data.input)
        end
    end
    collectgarbage("collect")
    return result;
end
--data.session.domain
--data.session.dgl_domain   = "@";
--data.session.used_domain_set.num = 0;
--data.session.used_domain_set.set = {};
--data.session.lbs_city. = "";
--data.session.use_2pass = true;
local env_map = {
  ["domain"]        = "domain",
  ["dlg_domain"]     = "dlg_domain",
  ["lbs_city"]      = "lbs_city", 
  ["use_2pass_sem"] = "use_2pass"    
}

function M:env_parser(env_str)
    local result = {}
    local slot_index
    local is_empty = true
    
    for k,v in string.gmatch(env_str, "%s*([%w_]+)%s*=%s*([^%s;]+)%s*;") do                       
        local key = env_map[k]
        if key then
            is_empty = false            
            if v == "1" then                
                result[key] = 1
            elseif v == "0" then                
                result[key] = 0
            else                
                if key == "domain" then                    
                    local cnt = 0                    
                    local update = string.gsub(v,[["]],"")
                    if update then
                        v = update
                    end                                         
                    local value = v..","                    
                    for v1 in string.gmatch(value,"([^,]+),") do
                        cnt = cnt + 1                        
                        if not result["used_domain_set"] then
                            result.used_domain_set = {}
                            result.used_domain_set.set = {}
                        end
                        table.insert(result.used_domain_set.set,v1)
                    end
                    if cnt == 1 then
                        result[key] = v
                        result.used_domain_set.set = nil
                        result.used_domain_set.num = 0
                    else
                        result.used_domain_set.num = cnt
                    end
                else                
                    result[key] = v
                end
            end
        else
            if k == "use_slot_index" then
                if v == "1" then
                    slot_index = 1
                elseif v == "0" then
                    slot_index = 0
                else
                    slot_index = nil
                end                     
            end
        end
    end
    
    if is_empty then
        result = nil
    end    
    return result,slot_index
end

function M:feed_json(jsondata)     
    local input,output
    local data = {}
    
    input = json.decode(jsondata)    
    if input.refText then
        if not data.input then
            data.input = {}
        end
        data.input.reftext = input.refText
    end
    
    if input.pinyin then
        if not data.input then
            data.input = {}
        end
        data.input.pinyin = input.pinyin
    end
    
    if input.env then
        local slot_index
        data.session, slot_index = self:env_parser(input.env)
        if slot_index then
            if not data.opts then
                data.opts = {}
            end
            data.opts.use_slot_index = slot_index
        end    
    end
    if input.output_format then
        data.output_format = input.output_format
    end
        
    if input.request_version then
        data.request_version = input.request_version
    end
    
    if input.wakeupWord then
        if not data.wakeup then
            data.wakeup = {}
        end
        data.wakeup.word = input.wakeupWord        
    end            
    
    if input.commonWakeupWord then
        if not data.wakeup then
            data.wakeup = {}
        end
        if not data.wakeup.common then
            data.wakeup.common = {}
        end
        data.wakeup.common.word = input.commonWakeupWord        
    end
    
    if input.commonWakeupWordPinyin then
        if not data.wakeup then
            data.wakeup = {}
        end
        if not data.wakeup.common then
            data.wakeup.common = {}
        end
        data.wakeup.common.pinyin = input.commonWakeupWordPinyin        
    end
    
    if input.customWakeupWord then
        if not data.wakeup then
            data.wakeup = {}
        end
        if not data.wakeup.custom then
            data.wakeup.custom = {}
        end
        data.wakeup.custom.word = input.customWakeupWord        
    end
    
    if input.customWakeupWordPinyin then
        if not data.wakeup then
            data.wakeup = {}
        end
        if not data.wakeup.custom then
            data.wakeup.custom = {}
        end
        data.wakeup.custom.pinyin = input.customWakeupWordPinyin        
    end
    
    output = json.encode(self:feed(data))    
    output = string.gsub(output,"%[%]","%{%}")
    self:reset()    
    return output
end

function M:set_opts( opts )    
    if opts.use_slot_index then
        self.use_index = (opts.use_slot_index == 1 )        
    end
    if opts.use_stop_word then
        self.opts.use_stop_word = (opts.use_stop_word == 1 )
    end
    if opts.use_force_domain then
        self.opts.use_force_domain = (opts.use_force_domain == 1 )
    end
    if opts.use_reform then      
        self.opts.use_reform = (opts.use_reform == 1 )
    end
    if opts.use_merge then
        self.opts.use_merge = (opts.use_merge == 1 )
    end
    self.modules["pre"].opts = self.opts
    self.modules["post"].opts = self.opts
    self.modules["reform"].opts = self.opts
end

function M:reset_opts()
    self.opts = self.cfg.opts
    self.modules["pre"].opts = self.opts
    self.modules["post"].opts = self.opts
    self.modules["reform"].opts = self.opts
end    

function M:reset()    
    
    self:reset_domain()
    self:reset_session()
    self:reset_opts()
    
    self.processor.input = ""
    self.processor.pinyin = ""
    
    self.engine.running = ""
    self.domain = "@"
    self.input = ""
    self.jump_domain = "@"
    self.source = "@"
    self.request_version = ""
    self.use_index = self.cfg.use_index 
    if self.cfg.output_format then
        self.output_format = self.cfg.output_format
    else
        self.output_format = nil
    end
    self.domain_act = nil
    self.confidence = nil
end

function M:release( )
--    M:function_print("release",nil)
    self:reset()
end

------ debug functions
function M:print_data(data)
    if self.debug then
        local json = require 'utils.json';
        local str;
        if data == nil then
            str = ""
        else
            str = json.encode(data);   
        end
        print(str);
    end
end

function M:function_print(func, data)
    local debug = false;
    local json = require 'utils.json';
    local str;
	if( debug ) then
      	str = json.encode(data);
	print(func,", param: ",str );
    end
end

function M:trace(str)
    if self.use_trace then
        print(str)
    end
end 


function M:local_slots_update_by_case( sem, tokens )
    local act = {}
    local slots = {}
    local statistics_slots = {}
    local slot_cnt = 0
    local stat_cnt = 0

    debug_str = nil
    if table.maxn(tokens)>0 then
        -- table.sort(tokens,function(a,b) return a.__WEIGHT__ > b.__WEIGHT__ end)
    end

    for i,token in pairs(tokens) do
        if token.__NAME__ == "CRF" or token.__NAME__ == "LMLEX" then
            debug_str = "Rule: <"..token.__NAME__.."> :[__RE_START__="..tostring(token.__RE_START__)..",__RE_END__="..tostring(token.__RE_END__).."]"
        else
            debug_str = "Rule: <"..token.__NAME__.."> :[__RE_START__="..tostring(token.__RE_START__)..",__RE_END__="..tostring(token.__RE_END__).."]"
        end

        for k,v in pairs(token) do
            if k ~= "__WEIGHT__" and k ~= "__RE_START__" and k~= "__RE_END__" and k~= "__KEY__" and k~="__NAME__" and k~="__SEQ__" and k~= "__ID__" then
                for s in string.gmatch(k,"([^:]+)") do
                    local tmp = {}
                    tmp.__WEIGHT__   = token.__WEIGHT__
                    tmp.__RE_START__ = token.__RE_START__
                    tmp.__RE_END__   = token.__RE_END__
                    tmp.__NAME__     = token.__NAME__
                    if token.__SEQ__ then
                        tmp.__SEQ__      = token.__SEQ__
                    else
                        tmp.__SEQ__ = 0
                    end

                    tmp.__KEY__ = s
                    if type(v)=="string" then
                        tmp[s]={[1]=v,[2]=-1,[3]=-1}
                        tmp.__SLOT_START__ = -1
                        tmp.__SLOT_END__   = -1
                    else
                        tmp[s] = v
                        tmp.__SLOT_START__ = v[2]
                        tmp.__SLOT_END__   = v[3]
                    end

                    debug_str = debug_str.."\n    "..s..":[__VALUE__="..tmp[s][1]..",__SLOT_START__="..tostring(tmp[s][2])..",__SLOT_END__="..tostring(tmp[s][3])..",__WEIGHT__="..tostring(token.__WEIGHT__).."]"

                    if token.__NAME__ == "CRF" or token.__NAME__ == "LMLEX" then
                        debug_str = debug_str.."\n--=--=--=--=--=--=--=--=--=--=--=--=--=--=--=--=--=--=--=--=--=--=--=--=--=--=--=--=--=--=--=--"
                        tmp.__SORT__ = stat_cnt
                        table.insert(statistics_slots,tmp)
                        stat_cnt = stat_cnt + 1
                    else
                        if tmp[tmp.__KEY__][1] ~= "__NIL__" then
                            tmp.__SORT__ = slot_cnt
                            table.insert(slots,tmp)
                            slot_cnt = slot_cnt + 1
                        end
                    end
                end
            end
        end
        self:trace(debug_str)
    end

    if not debug_str then
        self:trace("null")
    end

    if table.getn(slots) > 0 then
        self:lex_slots_to_act(slots,sem, act)
    end
    if table.getn(statistics_slots) > 0 then
        self:statistics_slots_to_act(statistics_slots, sem, act)
    end
    --[[
    local cnt = 0
    if table.maxn(act) > 0 then
        local tmp
        for k,v in pairs(act) do
 --           if v.data.__VALUE__ == "" then
 --                act[k] = nil
 --           else
                if not tmp then
                    tmp = {}
                end
                v.data.__SORT__ = cnt
                table.insert(tmp,v)
                cnt = cnt + 1
--            end
        end
        act = tmp
    end
    --]]
    if not act then
        act = {}
    end

    return sem,act
end

function M:local_tokens_to_act(output)
    local sem = {}
    local act = {}

    if not output.tokens then
        return nil
    end

    sem.domain       = self.domain
    sem.source       = self.source
    sem.input        = self.processor.input
    sem.domain_nbest = self.nbest
    sem.use_2pass    = self.session.use_2pass
    sem.dlg_domain   = self.session.dlg_domain
    sem.jump_domain  = self.jump_domain

    sem,act = self:local_slots_update_by_case(sem,output.tokens)

    return sem,act
end

local function statistics_slots_to_tokens(engine, result)
    local tokens_result = {}
    tokens_result.tokens = {}
    tokens_result.nTokens = 0
    local re_start,re_end
    re_start = nil
    re_end = 0
    for k,v in pairs(result[engine]) do
        for k1, v1 in pairs(v) do
            if not re_start then
                re_start = v1[2]
            elseif re_start  > v1[2] then
                re_start = v1[2]
            end
            if re_end < v1[3] then
               re_end = v1[3]
            end
        end
    end

    for k2,v2 in pairs(result[engine]) do
        for k3, v3 in pairs(v2) do
            local tmp = {}
            tmp[k3] = v3
            tmp.__WEIGHT__ = 1.0
            tmp.__RE_START__ = re_start
            tmp.__RE_END__ = re_end
            tmp.__NAME__ = string.upper(engine)
            tmp.__SEQ__ = 0
            tmp.__ID__ = 0
            table.insert(tokens_result.tokens,tmp)
            tokens_result.nTokens = tokens_result.nTokens + 1
        end
    end
    return tokens_result
end

function M:merge_lex_crf(lex_result,crf_result)
    local lex_cnt = table.maxn(lex_result.act)
    local act = {}
    local tmp_sem = {}
    if table.maxn(crf_result.act) > 0 then
        local ignore_key_list = {}
        for k,v in pairs(crf_result.act) do
            local flag = false
            local ignore = false
            for k1, v1 in pairs(lex_result.act) do
                if v.key == v1.key then
                    v.data.__SORT__ = v1.data.__SORT__
                    flag = true
                    if (v1.data.__VALUE__ == v.data.__VALUE__) or
                       (v1.data.__VALUE__ ~= "" and v1.data.__SLOT_START__ <= v.data.__SLOT_START__ and v1.data.__SLOT_END__ >= v.data.__SLOT_END__) then
                         ignore = true
                         break
                    end
                end
            end

            if not ignore then
                if flag == false then
                    lex_cnt = lex_cnt + 1
                    v.data.__SORT__ = lex_cnt
                end
                table.insert(lex_result.act,v)
            end
        end
    end
    act = lex_result.act
    local cnt = 0
    if table.maxn(act) > 0 then
        local tmp
        for k,v in pairs(act) do
 --           if v.data.__VALUE__ == "" then
 --                act[k] = nil
 --           else
                if not tmp then
                    tmp = {}
                end
                --v.data.__SORT__ = cnt
                table.insert(tmp,v)
                --cnt = cnt + 1
--            end
        end
        act = tmp
    end

    if not act then
        act = {}
    end

    lex_result.sem.domain_act   = self.domain_act 
    if self.processor_cb then
       if table.maxn(act) > 1 then
--           table.sort(act,sort_by_slot_start)
           table.sort(act,sort_act)
       end
       tmp_sem, act = self.processor_cb:reform_cb_entry(lex_result.sem,act)
    end
    if lex_result.sem.confidence then
        self.confidence = lex_result.sem.confidence
    end

    if not act or tmp_sem.domain == "@" then
        return nil
    end

    local slots = {}
    local cnt=0
    local key_rcd = {}

    for key,value in pairs(act) do
        if value and value.data and value.data.__VALUE__ and value.data.__VALUE__ ~= "" and not key_rcd[value.key] then
            local slot = {}
            key_rcd[value.key] = true
            slot[value.key] = {[1]=value.data.__VALUE__, [2]=value.data.__SLOT_START__,[3]=value.data.__SLOT_END__}
            slot.__WEIGHT__ = value.data.__WEIGHT__
            table.insert(slots,slot)
            cnt = cnt+1
        end
    end

    return slots
end

function M:local_delete_none_slot(act)
    local tmp = {}
    for k,v in pairs(act) do
        if v.data then
            table.insert(tmp,v)
        end
    end
    return tmp
end

function M:local_process_query_crf(domain,lex_result)
    local result
    local merge_result = {}
    local crf_result = {}
    local data ={}
    local cfg = {
        model_fn = ""
        }
    local output
    local crf_output = {}

    if self.db.crf[domain] then
        cfg.model_fn = self.db.crf[domain].model_fn.fn
        if self.db.crf[domain].dict_tbl[1] and self.db.crf[domain].dict_tbl[1].fn then
            cfg.dict_fn = self.db.crf[domain].dict_tbl[1].fn
            cfg.dict_str_len = self.db.crf[domain].dict_tbl[1].str_len
        else
            cfg.dict_fn = "";
            cfg.dict_str_len = 0;
        end
        cfg.use_mmap = self.db.crf.use_mmap
        output = self:run_engine_cached(domain,"crf", cfg, self.processor.input )
    end
    crf_output.crf = {}
    if output and table.maxn(output.crf)>0 then
        for i=1, table.maxn(output.crf) do
            for k, v in pairs(output.crf[i]) do
                local tmp = {}
                if self.db.crf[domain].mapping[k] then
                    tmp[self.db.crf[domain].mapping[k]] = v
                    table.insert(crf_output.crf,tmp)
                end
            end
        end
    end

    result = statistics_slots_to_tokens("crf", crf_output)
    crf_result.sem,crf_result.act = self:local_tokens_to_act(result)
    crf_result.sem,crf_result.act,lex_result.act= self.processor_cb:reform_crf_entry(crf_result.sem,crf_result.act,lex_result.act)
    lex_result.act = self:local_delete_none_slot(lex_result.act)
    crf_result.act = self:local_delete_none_slot(crf_result.act)
    result = self:merge_lex_crf(lex_result,crf_result)
    if result then
        merge_result.tokens = result
        merge_result.nTokens = 1
    else
        merge_result.nTokens = 0
        merge_result.tokens = {}
    end
    return merge_result
end

function M:local_process_query_lex(domain,data)
    local input,result
    local lex_result = {}
    input = data.reftext

    if domain ~= self.key.no_domain then
        local debug_str = "-=- local query lex -=- \ndomain="..domain
        self:trace(debug_str)
        result = self:process_in_domain( domain, input )
    end

    if not result then
        result = {}
        result.nTokens = 1
        result.tokens = {}
        result.tokens[1] = nil
    end
    lex_result.sem,lex_result.act = self:local_tokens_to_act(result)
    return lex_result
end

function M:local_process( data )
    local result,lex_result,weight
    local start_time, end_time

    start_time = self.engines["core"]:get_time()

    if data.pinyin then
        self.processor.pinyin = data.pinyin
    else
        self.processor.pinyin = ""
    end
    self.modules["reform"]:set_pinyin(self.processor.pinyin)

    if data.reftext then
        local domain=nil
        domain = self:get_session_domain()
        if domain == self.key.no_domain or domain == nil then
            domain,weight = self:query_domain( data.reftext );
        else
            self.domain = domain
            weight = 1
        end
        if self.domain == "地图" then
            lex_result = self:local_process_query_lex(self.domain,data);
            if self.debug then
                print("Post.......................................")
                self:print_data(lex_result)
            end

            if lex_result then
                if self.debug then
                    print("crf..........................................")
                end
                result = self:local_process_query_crf(self.domain,lex_result)
            end
        else
            result = {}
            result.nTokens = 0
            result.tokens = {}
        end

        if result and self.opts.use_reform then
            local param = {}
            param.skill = self.sys.name
            param.domain = self.domain
            param.dlg_domain = self:get_session_dlg_domain()
            end_time  = self.engines["core"]:get_time()
            param.time  = end_time-start_time
            param.res   = self.sys.res
            param.input_str = self.input
            param.input = self.processor.input
            param.jump_domain = self.jump_domain
            if self.confidence then
                param.confidence = self.confidence
            end
            -- 保证nbest的confidence <= 前一个的confidence
            local preconf = self.confidence
            if self.nbest then
                for ii,ndom in pairs(self.nbest) do 
                    if ndom and ndom.confidence and preconf then
                        if ndom.confidence > preconf then 
                            self.nbest[ii].confidece  = preconf
                        end
                        preconf = ndom.confidence
                    end
                end
            end
            if not self.output_format or self.output_format == "WTK" then
            if self.use_wtk_version or self.output_wtk_format then
                param.nbest = self.nbest
                result = self.modules["reform"]:reform_output_with_wtk_format(param,result,{})
                if self.use_wtk_version then
                    if self.reform_ves then
                            result = self.reform_ves:version_transform(self.request_version,self.sys.res,result,self.use_index,self.output_format)
                    end
                    if not self.use_index then
                        result = delindex(result)
                    end
                end
                end
            elseif self.output_format == "DUI" then
                param.nbest = self.nbest
                result = self.modules["reform"]:reform_output(param,result)    --转为nlu上层需要的json格式
                if self.reform_ves then
                    result = self.reform_ves:version_transform(self.request_version,self.sys.res,result,self.use_index,self.output_format)
                end    
            else
                self:trace("wrong output format")
            end

            self.nbest = {}
            if self.debug then
                print("Reform.......................................")
                self:print_data(result)
            end
        end
    end
    return result
end

return M
