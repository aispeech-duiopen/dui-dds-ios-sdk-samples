package.cpath = "/home/aisp/project/lex/semantic_v3/.libs/semantic.so"
package.path = "./semantic/?.lua;./res/?.lua;./?.lua;" --此路径配置需考虑nlucfg.lua与lexcfg.lua的路径

local kvbuilder = require 'kvbuilder'

local builder = kvbuilder.new()
--builder:append_file( filename, len_of_filename)
--builder:append_line( lines, len_of_lines ) 
--builder:dump_bin(binname, len_of_binname)
local input  = "test.txt"
local output = "test.bin"
builder:append_file( input, string.len(input))
builder:dump_bin(output, string.len(output))

builder = nil



