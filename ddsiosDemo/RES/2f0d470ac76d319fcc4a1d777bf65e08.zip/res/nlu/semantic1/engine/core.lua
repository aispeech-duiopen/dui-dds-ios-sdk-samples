require("utils.base")
local M = {}
local sem = require("semantic")

function M:get_time(in_ms)
    if in_ms == nil or in_ms == true then
        return sem.get_ms()
    else
        return sem.get_ms() / 1000.0
    end
end

function M:utf8_bytes(ch)
    return sem.get_utf8_bytes(ch)
end

function M:word_bytes(str)
    return sem.get_word_bytes(str)
end

function M:sub_word_string(str,from,to)
    return sem.get_sub_word_string(str,from,to)
end

function M:word_string_len(str)
    return sem.get_word_string_len(str)
end

function M:get_version()
    return sem.get_build_time()
end

return M
