local def = require("utils.base")
local json = require("utils.json")
local M = def:class()

M.instance = nil

function M:__init__(j, pwd, group)
    if j == nil then
        j = {}
    end
    if pwd == nil then
        pwd = "."
    end
    local lmlex = require("semantic.lmlex")
    local js = json.encode(j)    
    
    self.instance = lmlex.new(js, pwd)
    if self.instance == nil then
        self = nil
    end
end

function M:__del__()
    -- print("gc:", self)
    self.instance = nil
end

function M:__str__()
    return "NLU Lmlex Engine: " .. tostring(self.instance)
end

function M:feed(data,skillid)
    local input
    input = json.encode(data)    
    local ret = self.instance:feed(input, string.len(input))    
    return ret
end

function M:match(input)        
    local ret = self.instance:match(input, string.len(input))    
    return ret
end

function M:get_result()    
    local str = self.instance:get_result()    
    return json.decode(str)        
    --return json.decode(self.instance:get_result())
end

function M:reset()
    return self.instance:reset()
end

function M:delete()
    return self.instance:delete()
end

return M
