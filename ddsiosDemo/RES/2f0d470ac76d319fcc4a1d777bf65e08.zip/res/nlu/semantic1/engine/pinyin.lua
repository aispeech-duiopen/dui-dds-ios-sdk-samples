local def = require("utils.base")
local json = require("utils.json")
local M = def:class()

M.instance = nil

function M:__init__(j, pwd)
    if j == nil then
        j = {}
    end
    if pwd == nil then
        pwd = "."
    end
    local pinyin = require("semantic.pinyin")
    
    local js = json.encode(j)        
    self.instance = pinyin.new(js, pwd)
    
    
    if self.instance == nil then
        self = nil
    end
end

function M:__del__()
    -- print("gc:", self)
    self.instance = nil
end

function M:__str__()
    return "NLU Pinyin Engine: " .. tostring(self.instance)
end

function M:feed(input,skillid)
    local ret = self.instance:feed(input, string.len(input))
    
    return ret
end

function M:get_result()    
    local tbl,pinyin
    tbl = json.decode(self.instance:get_result())
    if tbl then
        if tbl.value then
            --pinyin = string.gsub(tbl.value," ","")
            pinyin = tbl.value
        end
    end          
    return pinyin
end

function M:reset()
    return self.instance:reset()
end

function M:delete()
    return self.instance:delete()
end

return M
