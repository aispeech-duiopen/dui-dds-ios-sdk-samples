local def = require("utils.base")
local json = require("utils.json")
local M = def:class()

M.instance = nil

function M:__init__(fn,name)
    if fn == nil then
        fn = ""
    end
    
    local vocabs = require("semantic.vocabs")
        
    
    self.instance = vocabs.new(fn,name)
    if self.instance == nil then
        self = nil
    end
end

function M:__del__()
    -- print("gc:", self)
    self.instance = nil
end

function M:__str__()
    return "NLU Vocabs Engine: " .. tostring(self.instance)
end

function M:feed(input)
    local ret = self.instance:feed(input, string.len(input))
    
    return ret
end

function M:get_result()    
    local result
    local ret = false
    result = self.instance:get_result()
    if result == "PASS" then
        ret = true
    end
              
    return ret
end

function M:query(input)
    local ret = self.instance:query(input, string.len(input))
    
    return ret
end

function M:get_query_result()    
    local result
    
    result = self.instance:get_query_result()
                  
    return result
end


function M:reset()
    return self.instance:reset()
end

function M:delete()
    return self.instance:delete()
end

return M
