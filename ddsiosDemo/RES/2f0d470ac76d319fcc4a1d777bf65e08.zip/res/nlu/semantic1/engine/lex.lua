local def = require("utils.base")
local json = require("utils.json")
local M = def:class()

M.instance = nil

function M:__init__(j, pwd, group)
    if j == nil then
        j = {}
    end
    if pwd == nil then
        pwd = "."
    end
    local lex = require("semantic.lex")
    local js = json.encode(j)    
    --print(js)
    self.instance = lex.new(js, pwd, group)
    if self.instance == nil then
        self = nil
    end
end

function M:__del__()    
    self.instance = nil
end

function M:__str__()
    return "NLU Lex Engine: " .. tostring(self.instance)
end

function M:feed(input,skillid)
    local ret,bytes
     
    if skillid then
        bytes = string.len(skillid)
    else
        bytes = 0;
    end
    
    ret = self.instance:feed(input, string.len(input),skillid,bytes)
    
    return ret
end

function M:get_result()
    --for test    
    --local output = "{\"nTokens\": 1, \"tokens\": [{\"日期\":{\"__SLOT_START__\":0,\"_日期\":{\"_日期1\":{\"_相对日\":{\"offset\":\"1\",\"__POST__\":\"_xday\"}}},\"__SLOT_END__\":1},\"domainflag1\":\"天气\",\"__RE_START__\":7,\"__RE_END__\":0,\"__WEIGHT__\":0.850000}]}"
    --local output = [[{"nTokens":3,"tokens":[{"__WEIGHT__":0.75,"intent":"打电话","__RE_END__":6,"__RE_START__":0,"联系人":{"__SLOT_START__":6,"__SLOT_END__":9,"联系人":{"sys.人名":"鹏程"}}},{"__WEIGHT__":0.5,"intent":"打电话","__RE_END__":6,"__RE_START__":0,"联系人":{"联系人":{"sys.人名":"鹏程"}}},{"__WEIGHT__":0.75,"intent":"打电话","__RE_END__":6,"__RE_START__":0,"联系人1":{"__SLOT_START__":7,"__SLOT_END__":8,"联系人1":{"sys.人名":"鹏程"}}}]}]]    
    --local ouput = [[{"nTokens":3,"tokens":[{"__WEIGHT__":0.75,"intent":"打电话","__RE_END__":6,"__RE_START__":0,"联系人":{"联系人":{"sys.人名":"鹏程"}}},{"__WEIGHT__":0.5,"intent":"打电话","__RE_END__":6,"__RE_START__":0,"联系人":{"联系人":{"sys.人名":"鹏程"}}},{"__WEIGHT__":0.75,"intent":"打电话","__RE_END__":6,"__RE_START__":0,"联系人2":{"联系人2":{"sys.人名":"刘洪彬"}}}]}]]
    --local output = [[{"nTokens":2,"tokens":[{"__WEIGHT__":0.75,"intent":"打电话","__RE_END__":5,"__RE_START__":0,"联系人":{"__SLOT_START__":4,"__SLOT_END__":5,"联系人":{"sys.人名":"徐华"}}},{"__WEIGHT__":0.5,"intent":"打电话","__RE_END__":5,"__RE_START__":0,"联系人1":{"__SLOT_START__":3,"__SLOT_END__":5,"联系人1":{"sys.人名":"打华"}},"联系人":{"__SLOT_START__":4,"__SLOT_END__":5,"联系人":{"sys.人名":"徐打华"}}}]}]]
    --local output = [[{"nTokens":1,"tokens":[{"序列号":{"__SLOT_START__":0,"_序列号_0":{"_序列号1_1":{"@2":{"整数_2":{"中文整数_3":{"value":{"中文数2_4":{"中文数字_13":{"中文七_14":"七"},"中文单位_7":{"中文百_8":"百"},"中文单位_11":{"中文十_12":"十"},"中文数字_5":{"中文三_6":"三"}}},"__POST__":"_num"}}},"_序列号量词_15":"个"}},"__SLOT_END__":6},"__WEIGHT__":0.3,"__RE_END__":6,"__RE_START__":0,"intent":"用户选择"}]}]]
    --local output = [[{"nTokens":1,"tokens":[{"__WEIGHT__":0.5,"终点名称":{"__SLOT_START__":0,"__SLOT_END__":3,"变量2_0":{"变量1_1":"变量","变量1_2":"变量"}},"__RE_START__":0,"__RE_END__":3}]}]]
    --local output = [[{"nTokens":1,"tokens":[{"序列号":{"__SLOT_START__":0,"_序列号_0":{"_序列号1_1":{"@2":{"整数_2":{"中文整数_3":{"value":{"中文数2_4":{"中文单位_7":{"中文百_8":"百"},"中文数字_5":{"中文三_6":"三"}}},"__POST__":"_num"}}},"_序列号量词_9":"个"}},"__SLOT_END__":3},"__WEIGHT__":0.5,"__RE_END__":3,"__RE_START__":0,"intent":"用户选择"}]}]]
    --local output = [[{"nTokens":1,"tokens":[{"__WEIGHT__":0,"歌手名":{"__SLOT_START__":3,"singerlabel_or2_0":{"item2":{"singerlabel_or1_2":{"item":{"歌手名_3":{"music_歌手名":"张学友"}},"__POST__":"_or"}},"__POST__":"_logical","item1":{"歌手名_1":{"music_歌手名":"刘德华"}}},"__SLOT_END__":9},"__RE_START__":3,"__RE_END__":9}]}]]
    --local output = [[{"nTokens":1,"tokens":[{"__WEIGHT__":0.5201,"__RE_END__":2,"__RE_START__":0,"日期":{"__SLOT_START__":0,"__SLOT_END__":2,"阳历日期_0":{"_阳历日期_1":{"_阳历日期2_2":{"__POST__":"_yearfutureaddnearby","day":{"_日1_7":{"@1":{"基础数字_8":{"1_9":"1"}}}},"month":{"_阳历月_3":{"_阳历月份_4":{"@1":{"基础数字_5":{"3_6":"3"}}}}}}}}}}]}]]
    --local output = [[{"nTokens":2,"tokens":[{"__WEIGHT__":0.75,"__RE_END__":13,"时间":{"时间_5":{"时间_tk0003_6_6":{"_时间_7":{"_下午时间_8":{"_下午一点_9":{"hour":{"chn3_10":"3"},"_小时_11":"点","__POST__":"_hour3add12"}}}}},"__SLOT_START__":2,"__SLOT_END__":5},"intent":"查天气","城市":{"__SLOT_START__":6,"城市_12":{"sk0001_sys.城市名":"上海"},"__SLOT_END__":7},"__RE_START__":0,"日期":{"__SLOT_START__":0,"日期_0":{"日期_tk0003_0_1":{"_阳历日期_2":{"_相对日_3":{"offset":{"_今天_4":"0"},"__POST__":"_xday"}}}},"__SLOT_END__":1}},{"__WEIGHT__":0.75,"__RE_END__":13,"时间":{"时间_6":{"时间_tk0003_6_7":{"_时间_8":{"_下午时间_9":{"_下午一点_10":{"_小时_12":"点","hour":{"chn3_11":"3"},"__POST__":"_hour3add12"}}}}},"__SLOT_START__":2,"__SLOT_END__":5},"intent":"查天气","城市":{"__SLOT_START__":6,"城市_13":{"sk0001_sys.城市名":"上海"},"__SLOT_END__":7},"__RE_START__":0,"日期":{"__SLOT_START__":0,"日期_0":{"日期_tk0003_0_1":{"_日期_2":{"_日期1_3":{"_相对日_4":{"offset":{"_今天_5":"0"},"__POST__":"_xday"}}}}},"__SLOT_END__":1}}]}]]
    --local output = [[{"nTokens":1,"tokens":[{"__WEIGHT__":0.1,"股票代码":{"@2_10":{"基础数字1_11":"0"},"@2_4":{"基础数字1_5":"0"},"@2_8":{"基础数字1_9":"7"},"@2_12":{"基础数字1_13":"0"},"@2_6":{"基础数字1_7":"0"}},"__RE_END__":6,"__RE_START__":0,"日期":{"__SLOT_START__":0,"日期_0":{"_日期_1":{"_日期1_2":{"offset":{"offset_3":"0"},"__POST__":"_xday"}}},"__SLOT_END__":1}}]}]]    
    --return json.decode(output)
    --local output = self.instance:get_result()
    --print(output)
    --return json.decode(output)
    local output
    output = self.instance:get_result()    
    output = string.gsub(output,"__@__","")
    return json.decode(output)
end

function M:reset()
    return self.instance:reset()
end

function M:delete()
    return self.instance:delete()
end

return M
