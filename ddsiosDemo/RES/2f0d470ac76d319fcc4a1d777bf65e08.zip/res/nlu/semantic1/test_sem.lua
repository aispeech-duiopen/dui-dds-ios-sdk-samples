-- 配置luapath,主要是so和lua引用库的路径
package.cpath = "../libs/semantic.so"
package.path = "./semantic/?.lua;./?.lua"
print (package.path)

-- 引用相关的库
local nlucore = require 'nlucore'
local json = require 'utils.json'

--! @brief 字符串分隔迭代函数
--!
--! @param str 原始字符串
--! @param sep 分隔字符串
--! @param plain 是否将sep作为普通字符串，如果是false的话，如果sep中包含某些
--!        正则符号(比如，.,*,%s等等)，则将之当作正则表达式来搜索
local function iter_split(str, sep, start, plain)
    if nil==plain then plain = true end 

    local pos = start or 1
    return coroutine.wrap(function()
	if nil==sep or ''==sep then return coroutine.yield(str) end
	if nil==str or pos>#str then
	    return 
	end

	while pos<=#str do
	    local first, last = string.find(str, sep, pos, plain)
	    if first then
		if pos<first then
		    coroutine.yield(str:sub(pos, first-1))
		end
		pos = last + 1
	    else
		coroutine.yield(str:sub(pos))
		break
	    end
	end
    end)
end

local function parse_env_params(env_param) 
    tbl_params = {}
    for param in iter_split(env_param,";") do
        print(param)
        param_kv = {}
        for val in iter_split(param,"=") do 
            table.insert(param_kv,val);
        end
        tbl_params[param_kv[1]] = param_kv[2];
        print(param_kv[1],tbl_params[param_kv[1]])
    end

    return tbl_params;
end

local function print_help()
    print("lua ".. arg[0].."-d res_dir -v vocabs_path -s text [-i infile] -o outfile -env env_params")
end

function main()
    local text = nil
    local infile = nil
    local outfile = nil
    local env_param = nil
    local res_path = nil
    local vocab_path = nil

    --命令行参数处理
    local argcount = #arg
    local i = 1
    while i< argcount do 
        if arg[i] == "-s" then 
            text = arg[i+1]
            i=i+1
        elseif arg[i] == "-i" then
            infile = arg[i+1]
            i=i + 1
        elseif arg[i] == "-o" then 
            outfile  = arg[i+1]
            i = i+ 1
        elseif arg[i] == "-env" then 
            env_param  = arg[i+1]
            i = i+ 1
        elseif arg[i] == "-d" then
            res_path = arg[i+1]
            i = i+1
        elseif arg[i] == "-v" then
            vocab_path = arg[i+1]
            i = i+1
        end
        i=i+1
    end
    
    --env参数解析
    env_params = parse_env_params(env_param)
    
    if res_path== nil or res_path == "" then
        print_help()
        return
    end

    if (text==nil or text=="") and (infile ==nil or infile =="") then
        print_help()
        return 
    end

    if not vocab_path then
        vocab_path = res_path.."/lex/vocabs/"
    end
    --nlucore初始化
    fn_cfg   = "nlucfg.lua"               --默认都用这个名字
    --res_path   = "/home/hx055/hxdata3/NLP/work2017/works/semantic_rewrite/src/semantic_v3_lua/src/res1/aihome/" 
    vocabs_path = {vocab_path}  --这个必须要有,lexcfg.lua可以只配置词库名称

    local data = {}
    data.session = {}
    data.opts = {}
    if env_params and next(env_params) then
        for k,v in pairs(env_params) do 
            if k == "domain" then
                data.session.domain = v
            elseif k == "dlg_domain" then
                data.session.dlg_domain = v
            elseif k == "use_slot_index" then
                data.opts.use_slot_index=tonumber(v)
            end
        end
    end

--    data.session.domain = "电影搜索"
    data.input = {}
    if text and text ~= "" then
        local nlu = nlucore.new(fn_cfg,res_path,vocabs_path)
        nlu:preload_lex_resources()
        nlu.use_trace = true
        --nlu.debug = true

        data.input.reftext = text
        local result = nlu:feed(data) 
        nlu:reset()
        nlu = nil
        print("input: "..data.input.reftext)
        print(json.encode(result))

    elseif infile and infile ~="" then
        local fr = io.open(infile,"r")
        local fw = nil
        if outfile and outfile ~="" then
            fw = io.open(outfile,"w")
        end
        local nlu = nlucore.new(fn_cfg,res_path,vocabs_path)
        nlu.debug = false
        nlu:preload_lex_resources()
        while true do
            local line = fr:read("*l")
            if not line then
                break
            end
            data.input.reftext = line
            local result = nlu:feed(data)
            local resjson = json.encode(result)
            nlu:reset()
            --nlu = nil
            
            if fw then
                fw:write("input: "..data.input.reftext.."\n")
                fw:write(resjson .. "\n")     
            else
                print("input: "..data.input.reftext) 
                print(resjson)
            end
            --print(data.input.reftext)
            resjson = nil

        end
        fr:close()
        if fw then 
            fw:close()
        end
    end

    nlu = nil
    collectgarbage("collect")
end

main()


