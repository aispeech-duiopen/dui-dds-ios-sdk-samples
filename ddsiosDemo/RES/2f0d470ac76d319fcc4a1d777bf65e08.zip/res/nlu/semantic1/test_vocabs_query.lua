package.cpath = "/home/aisp/workspace/semantic_v3/.libs/semantic.so"
package.path = "/home/aisp/workspace/luanew/src/?.lua;/home/aisp/workspace/luanew/src/semantic/?.lua;./home/aisp/workspace/luanew/src/res/?.lua;./?.lua;" --此路径配置需考虑nlucfg.lua与lexcfg.lua的路径

local vocabs = require("vocabs_query")
    
local str = "三月六日三月八日"
vocabs:regex_query_config("regex", "nlucfg.lua", "/home/aisp/workspace/luanew/src/res","/home/aisp/workspace/luanew/src/res/lex/kv")
vocabs:regex_query(str);
