require("utils.base")
local M = {}

-- 若参数c 为英文字母（a0x61 ~ z0x7a  A0x41 ~ Z0x5a），则返回true 值，否则返回 false。
function M:isalpha(c)
    return ((c >= 0x61 and c <= 0x7a) or (c >= 0x41 and c <= 0x5a))
end

--' '   (0x20)	space (SPC) 空格符
--'\t'	(0x09)	horizontal tab (TAB) 水平制表符
--'\n'	(0x0a)	newline (LF) 换行符
--'\v'	(0x0b)	vertical tab (VT) 垂直制表符
--'\f'	(0x0c)	feed (FF) 换页符
--'\r'	(0x0d)	carriage return (CR) 回车符
function M:isspace(c)
    local tab = {[0x20] = 1, [0x09] = 1, [0x0a] = 1, [0x0b] = 1, [0x0c] = 1, [0x0d] = 1}
    
    return (tab[c] ~= nil)
end

-- 移除中文字符和英文字符之间的空白符，保留英文之间的空白
-- @param data: 输入的字符串
--[[
function M:remove_space(data)
    if data ~= nil then
        while string.find(data, "(%s)") 
        do
            data = string.gsub(data, "([^a-zA-Z]+)(%s+)([^a-zA-Z]+)", "%1%3")
            data = string.gsub(data, "(%s+)([^a-zA-Z]+)", "%2")
            data = string.gsub(data, "([^a-zA-Z]+)(%s+)", "%1")
        end
    end
    return data
end
--]]
function M:remove_space(data)
    local b, num, next_num, prev_num;
    local s, e, next_s, prev_s;
    local str="";
    local wordstr;
    local index=0;
    local ret;
    local bytes
    local core = require 'engine.core'
    
    bytes = string.len(data)
    s = 1;
    e = s + bytes;
    num = 0;

    while (s < e) 
    do
        b = 1;
        prev_s = s - num;
        local c = string.byte(data,s);
        num = core:utf8_bytes(c)
        next_s = s + num;
        local space = self:isspace(string.byte(data,s));
        if (num == 1 and self:isspace(string.byte(data,s))) then
            b = 0;
            prev_num = core:utf8_bytes(string.byte(data,prev_s));
            if (prev_num == 1 and self:isalpha(string.byte(data,prev_s))) then
                if (next_s < e) then
                    next_num = core:utf8_bytes(string.byte(data,next_s));
                    if (next_num == 1 and self:isalpha(string.byte(data,next_s))) then
                        b = 1;
                    else 
                        if (next_num == 1 and self:isspace(string.byte(data,next_s))) then
                            while (next_s < e) 
                            do
                                next_s = next_s + next_num;
                                next_num = core:utf8_bytes(string.byte(data,next_s));
                                if (next_num == 1 and self:isalpha(string.byte(data,next_s))) then
                                    b = 1;
                                    break;
                                else 
                                    if (next_num == 3) then
                                    b = 0;
                                    break;
                                    end
                                end
                            end
                        end
                    end
                end
            end
        end
        if (b == 1) then
             wordstr = string.sub(data,s,s+num-1);
             index = index + num;
             str = str..wordstr;
        end
        s = s + num;
    end

    return str
end

-- 目前只支持移除停用词；后续可以考虑停用词替换的问题
function M:filter_out(data, stop_words)
    if stop_words ~= nil and type(stop_words) == "table" then
        for _, v in pairs(stop_words) do
            if type(v) == "string" then
                data = string.gsub(data, v, "")
            end
        end
    end
    return data
end

return M
