-- Get current version number.
local _, _, majorv, minorv, rev = string.find(_VERSION, "(%d).(%d)[.]?([%d]?)")
local VersionNumber = tonumber(majorv) * 100 + tonumber(minorv) * 10 + (((string.len(rev) == 0) and 0) or tonumber(rev))

-- Declare current version number.
TX_VERSION = VersionNumber
TX_VERSION_510 = 510
TX_VERSION_520 = 520
TX_VERSION_530 = 530

return TX_VERSION
