require("utils.base")
local id, json

if not cjson then
    id, json = tryrequire("cjson", "utils.dkjson")
else
    id = 1
    json = cjson
end

local M = {}

function M.encode(data)
    if id == 1 then
        return string.gsub(json.encode(data), "\\", "")
    else
        return json.encode(data)
    end
end

function M.decode(data)
    return json.decode(data)
end

return M
