local M = {}
require("utils.version")
local _class = {}

local _pwd

function M:set_pwd(pwd)
    _pwd = pwd
end
-- class封装
function M:class(super)
    local class_type = {}
    
    class_type.__init__ = false
    class_type.__del__ = false
    class_type.__str__ = false
    class_type.super = super
    class_type.new = function(...)
        local obj = {}
        do
            local create
            create = function(c, ...)
                if c.super then
                    create(c.super, ...)
                end
                if c.__init__ then
                    c.__init__(obj, ...)
                end
            end
            create(class_type, ...)
        end
        
        local meta = {}
        meta.__index = _class[class_type]
        
        if class_type.__str__ ~= false then
            meta.__tostring = class_type.__str__
        end
        
        -- using proxy register __gc function
        local gc = class_type.__del__
        if gc ~= false then
            if TX_VERSION < TX_VERSION_520 then
                local proxy = newproxy(true)
                getmetatable(proxy).__gc = function(o)
                    class_type.__del__(obj)
                end
                obj.__gc = proxy
            else
                meta.__gc = function(o)
                    class_type.__del__(obj)
                end
            end
        end
        -- end
        
        setmetatable(obj, meta)
        return obj
    end
    local vtbl = {}
    _class[class_type] = vtbl
    
    setmetatable(
        class_type,
        {__newindex = function(t, k, v)
                vtbl[k] = v
            end}
    )
    
    if super then
        setmetatable(
            vtbl,
            {__index = function(t, k)
                    local ret = _class[super][k]
                    
                    vtbl[k] = ret
                    return ret
                end}
        )
    end
    
    return class_type
end

function tryrequire(...)
    local handler = function()
        return false
    end
    local idx = 1
    local args = {...}
    for _, name in pairs(args) do
        local err = xpcall(
            function()
                require(name)
            end,
            handler
        )
        
        if err ~= false then
            return idx, require(name)
        end
        idx = idx + 1
    end
        
    return 0, nil
end

-- 递归打印
local function print_r(t)
    local print_r_cache = {}
    local function sub_print_r(t, indent)
        if (print_r_cache[tostring(t)]) then
            print(indent .. "*" .. tostring(t))
        else
            print_r_cache[tostring(t)] = true
            if (type(t) == "table") then
                for pos, val in pairs(t) do
                    if (type(val) == "table") then
                        print(indent .. "[" .. pos .. "] => " .. tostring(t) .. " {")
                        sub_print_r(val, indent .. string.rep(" ", string.len(pos) + 8))
                        print(indent .. string.rep(" ", string.len(pos) + 6) .. "}")
                    elseif (type(val) == "string") then
                        print(indent .. "[" .. pos .. '] => "' .. val .. '"')
                    else
                        print(indent .. "[" .. pos .. "] => " .. tostring(val))
                    end
                end
            else
                print(indent .. tostring(t))
            end
        end
    end
    if (type(t) == "table") then
        print(tostring(t) .. " {")
        sub_print_r(t, "    ")
        print("}")
    else
        sub_print_r(t, "")
    end
    print()
end

table.print = print_r

function __require__(fn)
    local str
    str = string.gsub(fn,'/','%.')
    if not str then
        str = fn
    end
    --str = _pwd..'/'..str..".lua"
    --print(str)    
    --return require(PWD..'/'..str)
    --return dofile(str)
    if string.find(str,"^%.") then
        str = string.sub(str,2,-1)
    end
    if string.find(str,"%.lua") then
        str = string.match(str,"(.*)%.lua$")
    end
    print("require=====", str)
    return require(str)
end

return M    
