package.cpath = "/home/aisp/workspace/semantic_v3/.libs/semantic.so"
package.path = "./semantic/?.lua;./res/?.lua;./?.lua;" --此路径配置需考虑nlucfg.lua与lexcfg.lua的路径

local kvreader = require 'kvreader'

local reader = kvreader.new("/home/aisp/workspace/luanew/src/res/lex/kv/date_省份.bin")
local str = "浙江省"
reader:feed(str)
print(reader:get_result())

reader = nil



