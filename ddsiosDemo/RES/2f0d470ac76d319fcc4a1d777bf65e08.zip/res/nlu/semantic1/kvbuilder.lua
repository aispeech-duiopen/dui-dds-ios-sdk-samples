local def = require("utils.base")
local M = def:class()

M.instance = nil

function M:__init__()
    if j == nil then
        j = {}
    end
    if pwd == nil then
        pwd = "."
    end
    local kv_builder = require("semantic.kv.builder")
    
    self.instance = kv_builder.new()
    if self.instance == nil then
        self = nil
    end
end

function M:__del__()
    -- print("gc:", self)
    self.instance = nil
end

function M:__str__()
    return "KV Builder: " .. tostring(self.instance)
end

function M:append_file( filename, len_of_filename)
    local ret = self.instance:append_file( filename, len_of_filename )
    return ret
end

function M:append_line( lines, len_of_lines ) 
    local ret = self.instance:append_line( lines, len_of_lines ) 
    return ret
end

function M:dump_bin(binname, len_of_binname)
    local ret = self.instance:dump_bin(binname, len_of_binname)
    return ret
end

return M
