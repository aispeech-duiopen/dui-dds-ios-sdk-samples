--package.cpath = "/home/aisp/project/lex/semantic_v3/.libs/semantic.so"
--package.cpath = "/home/aisp/project/lex/semantic.so"
--package.cpath = "/home/aisp/workspace/semantic_v3/.libs/semantic.so"
--package.path = "/home/aisp/workspace/luanew/src/?.lua;/home/aisp/workspace/luanew/src/semantic/?.lua;./home/aisp/workspace/luanew/src/res/?.lua;./?.lua;" --此路径配置需考虑nlucfg.lua与lexcfg.lua的路径
package.cpath = "./tool/libs/semantic.so"
package.path = "./tool/semantic_lua/src/?.lua;./tool/semantic_lua/src/semantic/?.lua;"

local nlucore = require 'nlucore'
local fn_cfg  = "nlucfg.lua" --都改为用dofile实现文件load,文件名需要有.lua的后缀。 在lexcfg在nlucfg的文件名同样有此变动
local ext_path = {"./tool/semantic_lua/src/res/lex/kv"}
local json = require 'utils.json'

function sem_test( cfg, input )
    local ret,str

    local nlu = nlucore.new(fn_cfg, "./tool/semantic_lua/src/res",ext_path)

    nlu:set_test_mode("wtk")
    --nlu.use_lmlex = false
    --nlu.use_crf = false
    nlu.debug = false
    
    local data = {}
    if cfg and cfg ~= "" then
        local session
        cfg = string.gsub(cfg,"=",":")
        --cfg = "{".."session:".."{"..cfg.."}".."}"
        cfg = "{"..cfg.."}"
        print(cfg)        
        data.session = json.decode(cfg)
        table.print(data.session)            
    end
    
    data.skillid = "sk0001"
    data.input = {
         reftext = ""
    }
    data.input.reftext = input;
    ret = nlu:feed(data)    
    
    nlu:reset()
    nlu = nil
    
    str = json.encode(ret);    
            
    return str
end
